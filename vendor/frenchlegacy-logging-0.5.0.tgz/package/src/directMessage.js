'use strict';

/**
 * MP Discord reçu par un bot → entrée de publish(), au même format pour les
 * trois bots. Post `prives` : texte, liens des pièces jointes et des stickers
 * (les fichiers ne sont pas re-téléversés). Base : métadonnées, texte du MP
 * (messageText → log_event.summary) et nombre de pièces jointes. Le bot
 * destinataire est la cible.
 *
 * @param {import('discord.js').Message} message message d'un salon DM, auteur humain
 * @returns {object} entrée de AuditLogger.publish()
 */
function directMessageEvent(message) {
    const fields = [];
    const attachments = [...(message.attachments?.values?.() || [])];
    const stickers = [...(message.stickers?.values?.() || [])];
    if (attachments.length) {
        fields.push({ name: `📎 Pièces jointes (${attachments.length})`, value: attachments.map(a => `[${a.name}](${a.url})`).join('\n') });
    }
    if (stickers.length) {
        fields.push({ name: '🎨 Stickers', value: stickers.map(s => `[${s.name}](${s.url})`).join('\n') });
    }
    const author = message.author;
    const bot = message.client?.user;
    return {
        category: 'prives',
        eventType: 'dm.received',
        status: 'success',
        origin: 'human',
        actorId: author.id,
        actorUsername: author.username,
        actorIsBot: false,
        ...(bot ? { targetId: bot.id, targetUsername: bot.username, targetIsBot: true } : {}),
        title: `💬 Message privé de ${author.tag || author.username}`,
        description: message.content || '*(aucun texte)*',
        fields,
        messageText: message.content || '',
        attachmentCount: attachments.length,
        context: { messageId: message.id }
    };
}

module.exports = { directMessageEvent };
