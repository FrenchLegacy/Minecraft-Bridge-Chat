'use strict';

/**
 * Logger par défaut (console) utilisé si aucun logger n'est injecté.
 * Le consommateur peut passer son propre logger via options.logger
 * tant qu'il expose { info, warn, error, debug }.
 */
const defaultLogger = {
    info : (...args) => console.log  ('[INFO] ',  ...args),
    warn : (...args) => console.warn ('[WARN] ',  ...args),
    error: (...args) => console.error('[ERROR]',  ...args),
    debug: (...args) => { if (process.env.DEBUG) console.debug('[DEBUG]', ...args); },
};

module.exports = defaultLogger;
