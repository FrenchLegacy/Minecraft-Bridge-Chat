/**
 * LocalDataCache - Cache local avec persistance fichier
 *
 * Stocke des données critiques en mémoire ET sur disque pour assurer :
 *   1. Des réponses rapides sans aller à l'API (lecture mémoire)
 *   2. La survie aux redémarrages (lecture depuis fichier JSON)
 *
 * @author Fabien83560
 * @version 1.0.0
 * @license ISC
 */

'use strict';

const defaultLogger = require('../utils/defaultLogger');

class LocalDataCache {
    /**
     * @param {object} [options]
     * @param {string} [options.cacheDir] - Répertoire de persistance
     * @param {object} [options.logger]
     */
    constructor(options = {}) {
        this.logger = options.logger || defaultLogger;
    }

    /**
     * Déclarer un store de cache.
     * @param {string} name
     * @param {object} [options]
     * @param {number} [options.ttlMs=600000]
     * @param {string} [options.fileName]
     */
    registerStore(name) {
        this.logger.debug(`[LocalDataCache] Store '${name}' enregistré (cache désactivé)`);
    }

    get(storeName, key) {
        return null;
    }

    set(storeName, key, data, ttlMs = null) {
        // Cache désactivé
    }

    invalidate(storeName, key) {
        // Cache désactivé
    }

    invalidateAll(storeName) {
        // Cache désactivé
    }

    setAll(storeName, entries) {
        // Cache désactivé
    }

    getStats() {
        return {};
    }

    saveAll() {
        // Cache désactivé
    }

}

module.exports = LocalDataCache;
