/**
 * CacheSyncManager - Synchronisation périodique du cache local avec l'API
 *
 * Rafraîchit proactivement les stores critiques en interrogeant l'API à
 * intervalles réguliers via des requêtes GET directes (hors file d'attente).
 *
 * @author Fabien83560
 * @version 1.0.0
 * @license ISC
 */

'use strict';

const defaultLogger = require('../utils/defaultLogger');

class CacheSyncManager {
    /**
     * @param {import('./LocalDataCache')}               cache
     * @param {import('../client/InternalApiClient')}    apiClient
     * @param {object} [options]
     * @param {number} [options.sanctionsIntervalMs=300000]
     * @param {number} [options.linksIntervalMs=900000]
     * @param {number} [options.usersIntervalMs=1800000]
     * @param {number} [options.initialDelayMs=5000]
     * @param {object} [options.logger]
     */
    constructor(cache, apiClient, options = {}) {
        this.cache     = cache;
        this.apiClient = apiClient;
        this.logger    = options.logger || defaultLogger;
        this.options   = {
            sanctionsIntervalMs : options.sanctionsIntervalMs || 300000,
            linksIntervalMs     : options.linksIntervalMs     || 900000,
            usersIntervalMs     : options.usersIntervalMs     || 1800000,
            initialDelayMs      : options.initialDelayMs      || 5000,
        };
        this._timers  = {};
        this._running = false;
    }

    start() {
        if (this._running) return;
        this._running = true;

        this._timers.sanctions = setInterval(() => this._syncSanctions(), this.options.sanctionsIntervalMs);
        this._timers.links     = setInterval(() => this._syncLinks(),     this.options.linksIntervalMs);
        this._timers.users     = setInterval(() => this._syncUsers(),     this.options.usersIntervalMs);

        setTimeout(() => this._syncAll(), this.options.initialDelayMs);

        this.logger.info(
            `[CacheSyncManager] Démarré — sanctions:${this.options.sanctionsIntervalMs}ms ` +
            `links:${this.options.linksIntervalMs}ms users:${this.options.usersIntervalMs}ms`
        );
    }

    stop() {
        for (const timer of Object.values(this._timers)) clearInterval(timer);
        this._timers  = {};
        this._running = false;
        this.logger.info('[CacheSyncManager] Arrêté');
    }

    forceSync() {
        this.logger.info('[CacheSyncManager] Synchronisation forcée');
        return this._syncAll();
    }

    async _syncAll() {
        await Promise.allSettled([this._syncSanctions(), this._syncLinks(), this._syncUsers()]);
    }

    async _syncSanctions() {
        try {
            const result = await this.apiClient.get('/sanctions?active=true');
            if (!result.success) {
                this.logger.warn(`[CacheSyncManager] Sync sanctions échouée: HTTP ${result.status}`);
                return;
            }
            const list    = Array.isArray(result.data) ? result.data : (result.data?.sanctions ?? []);
            const entries = {};
            for (const sanction of list) {
                const id = sanction.discordId || sanction.discord_id;
                if (!id) continue;
                if (!entries[id]) entries[id] = [];
                entries[id].push(sanction);
            }
            this.cache.setAll('sanctions', entries);
            this.logger.debug(`[CacheSyncManager] Sanctions: ${Object.keys(entries).length} utilisateur(s) synchronisé(s)`);
        } catch (err) {
            this.logger.warn(`[CacheSyncManager] Erreur sync sanctions: ${err.message}`);
        }
    }

    async _syncLinks() {
        try {
            const result = await this.apiClient.get('/users?linked=true');
            if (!result.success) {
                this.logger.warn(`[CacheSyncManager] Sync liens échouée: HTTP ${result.status}`);
                return;
            }
            const list    = Array.isArray(result.data) ? result.data : (result.data?.users ?? []);
            const entries = {};
            for (const user of list) {
                const id   = user.discordId || user.discord_id;
                const uuid = user.minecraftUuid || user.minecraft_uuid;
                if (!id || !uuid) continue;
                entries[id] = {
                    discordId         : id,
                    minecraftUuid     : uuid,
                    minecraftUsername : user.minecraftUsername || user.minecraft_username || null,
                };
            }
            this.cache.setAll('links', entries);
            this.logger.debug(`[CacheSyncManager] Liens: ${Object.keys(entries).length} entrée(s) synchronisée(s)`);
        } catch (err) {
            this.logger.warn(`[CacheSyncManager] Erreur sync liens: ${err.message}`);
        }
    }

    async _syncUsers() {
        try {
            const result = await this.apiClient.get('/users');
            if (!result.success) {
                this.logger.warn(`[CacheSyncManager] Sync users échouée: HTTP ${result.status}`);
                return;
            }
            const list    = Array.isArray(result.data) ? result.data : (result.data?.users ?? []);
            const entries = {};
            for (const user of list) {
                const id = user.discordId || user.discord_id;
                if (!id) continue;
                entries[id] = user;
            }
            this.cache.setAll('users', entries);
            this.logger.debug(`[CacheSyncManager] Users: ${Object.keys(entries).length} profil(s) synchronisé(s)`);
        } catch (err) {
            this.logger.warn(`[CacheSyncManager] Erreur sync users: ${err.message}`);
        }
    }
}

module.exports = CacheSyncManager;
