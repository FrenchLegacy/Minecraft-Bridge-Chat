/**
 * InternalApiManager - Façade principale du module d'API interne
 *
 * Point d'entrée unique pour toutes les interactions avec FrenchLegacy-API.
 * Orchestre :
 *   - InternalApiClient  : client HTTP authentifié
 *   - RequestQueue       : file d'attente FIFO multi-priorité
 *   - QueuePersistence   : persistance disque (survie aux crashes)
 *   - QueueWorker        : consommateur de la file avec retry/backoff
 *   - LocalDataCache     : cache local en mémoire + fichier
 *   - CacheSyncManager   : synchronisation périodique des données critiques
 *
 * Pattern Singleton : une seule instance par service (module-level).
 *
 * ─── Usage (CommonJS) ──────────────────────────────────────────────────────
 *
 *   const { getInstance } = require('@frenchlegacy/api-client');
 *   const internalApi = getInstance({
 *       baseUrl: 'http://frenchlegacy-api:10000',
 *       apiKey:  process.env.API_KEY,
 *       dataDir: '/app/data',
 *       logger:  myLogger,       // optionnel — { info, warn, error, debug }
 *   });
 *
 *   await internalApi.start();
 *
 *   // Lecture depuis le cache (immédiat)
 *   const user      = internalApi.getUser(discordId);
 *   const link      = internalApi.getUserLink(discordId);
 *   const sanctions = internalApi.getActiveSanctions(discordId);
 *
 *   // Écriture via file d'attente (asynchrone, garanti)
 *   internalApi.enqueue({ method: 'POST', endpoint: '/voice/sessions', body: {...} });
 *
 *   // Lecture directe GET (hors file)
 *   const result = await internalApi.get('/users/123');
 *
 * @author Fabien83560
 * @version 1.0.0
 * @license ISC
 */

'use strict';

const path = require('path');

const defaultLogger    = require('./utils/defaultLogger');
const InternalApiClient = require('./client/InternalApiClient');
const QueuePersistence  = require('./queue/QueuePersistence');
const RequestQueue      = require('./queue/RequestQueue');
const QueueWorker       = require('./queue/QueueWorker');
const LocalDataCache    = require('./cache/LocalDataCache');
const CacheSyncManager  = require('./cache/CacheSyncManager');

class InternalApiManager {
    /**
     * @param {object} [options]
     * @param {string} [options.baseUrl]         - URL de base de l'API (défaut: http://frenchlegacy-api:10000)
     * @param {string} [options.apiKey]          - Clé API (défaut: process.env.API_KEY)
     * @param {number} [options.timeout]         - Timeout HTTP en ms (défaut: 10000)
     * @param {string} [options.dataDir]         - Répertoire données persistantes (défaut: {cwd}/data)
     * @param {object} [options.logger]          - Logger injecté { info, warn, error, debug }
     * @param {object} [options.queue]           - Config queue { maxConcurrency, retryDelays, deadLetterMaxSize }
     * @param {object} [options.cache]           - Config cache { users, links, sanctions } → { ttlMs }
     * @param {object} [options.sync]            - Config sync { sanctionsIntervalMs, linksIntervalMs, usersIntervalMs }
     */
    constructor(options = {}) {
        const logger  = options.logger  || defaultLogger;
        const dataDir = options.dataDir || path.join(process.cwd(), 'data');

        // Client HTTP
        this.apiClient = new InternalApiClient({
            baseUrl : options.baseUrl || process.env.INTERNAL_API_URL || 'http://frenchlegacy-api:10000',
            apiKey  : options.apiKey  || process.env.API_KEY          || '',
            timeout : options.timeout || 10000,
            logger,
        });

        // Persistance
        const queueCfg    = options.queue || {};
        const persistence = new QueuePersistence({
            dataDir           : path.join(dataDir, 'queue'),
            deadLetterMaxSize : queueCfg.deadLetterMaxSize || 500,
            logger,
        });

        // File d'attente
        this._queue = new RequestQueue(persistence, { logger });

        // Restaurer les requêtes depuis le disque (crash recovery)
        const saved = persistence.loadPending();
        if (saved.length > 0) this._queue.load(saved);

        // Worker
        this._worker = new QueueWorker(this._queue, persistence, this.apiClient, {
            maxConcurrency : queueCfg.maxConcurrency || 1,
            retryDelays    : queueCfg.retryDelays    || [2000, 8000, 30000],
            logger,
        });

        // Cache local
        const cacheCfg = options.cache || {};
        this.cache = new LocalDataCache({
            cacheDir : path.join(dataDir, 'cache'),
            logger,
        });
        this.cache.registerStore('users',     { ttlMs: cacheCfg.users?.ttlMs     || 600000  });
        this.cache.registerStore('links',     { ttlMs: cacheCfg.links?.ttlMs     || 1800000 });
        this.cache.registerStore('sanctions', { ttlMs: cacheCfg.sanctions?.ttlMs || 300000  });

        // Synchronisation périodique
        this._syncManager = new CacheSyncManager(this.cache, this.apiClient, {
            ...(options.sync || {}),
            logger,
        });

        // Invalidation du cache après succès d'écriture
        this._worker.on('request:success', ({ item }) => {
            this._invalidateCacheForItem(item);
        });

        this._worker.on('request:dead', ({ item, result }) => {
            logger.error(
                `[InternalApiManager] Requête morte — ${item.method} ${item.endpoint} ` +
                `(tentatives: ${item.attempts}) : ${result.error || 'HTTP ' + result.status}`
            );
        });

        this._logger = logger;
    }

    // ── Cycle de vie ──────────────────────────────────────────────────────────

    async start() {
        this._logger.info('[InternalApiManager] Démarrage...');
        this._worker.start();
        this._logger.info(`[InternalApiManager] Prêt — ${this._queue.size} requête(s) restaurée(s) en file`);
    }

    async shutdown(gracePeriodMs = 10000) {
        this._logger.info('[InternalApiManager] Arrêt en cours...');
        this._syncManager.stop();
        this._worker.stop();

        const deadline = Date.now() + gracePeriodMs;
        while (this._worker._running > 0 && Date.now() < deadline) {
            await new Promise((r) => setTimeout(r, 200));
        }

        if (this._worker._running > 0) {
            this._logger.warn(`[InternalApiManager] Grace period expirée — ${this._worker._running} requête(s) abandonnée(s)`);
        }

        this._queue.persistImmediate();
        this._logger.info('[InternalApiManager] Arrêt terminé');
    }

    // ── API Publique — Écriture ───────────────────────────────────────────────

    /**
     * Ajouter une requête en file d'attente.
     * @param {object} options
     * @param {string} options.method
     * @param {string} options.endpoint
     * @param {object|null} [options.body]
     * @param {'high'|'normal'|'low'} [options.priority='normal']
     * @param {number} [options.maxAttempts=3]
     * @param {object} [options.metadata={}]
     * @returns {string} ID de la requête
     */
    enqueue(options) {
        return this._queue.push(options);
    }

    // ── API Publique — Lecture cache ──────────────────────────────────────────

    getUser(discordId)           { return this.cache.get('users', discordId); }
    setUser(discordId, data)     { this.cache.set('users', discordId, data); }
    getUserLink(discordId)       { return this.cache.get('links', discordId); }
    setUserLink(discordId, data) { this.cache.set('links', discordId, data); }
    getActiveSanctions(discordId) { return this.cache.get('sanctions', discordId) || []; }

    // ── API Publique — Lecture directe ───────────────────────────────────────

    get(endpoint)              { return this.apiClient.get(endpoint); }
    delete(endpoint, body)     { return this.apiClient.delete(endpoint, body); }

    // ── Statut & Maintenance ──────────────────────────────────────────────────

    getQueueStatus() {
        const workerStatus = this._worker.getStatus();
        const deadLetter   = this._queue.persistence?.loadDeadLetter() || [];
        return { ...workerStatus, deadLetterCount: deadLetter.length };
    }

    getCacheStats() { return this.cache.getStats(); }

    async flushDeadLetter() {
        const persistence = this._queue.persistence;
        const items       = persistence.loadDeadLetter();
        if (items.length === 0) {
            this._logger.info('[InternalApiManager] Dead letter vide — rien à rejouer');
            return 0;
        }
        for (const item of items) {
            this._queue.push({
                method      : item.method,
                endpoint    : item.endpoint,
                body        : item.body,
                priority    : item.priority    || 'normal',
                maxAttempts : item.maxAttempts || 3,
                metadata    : item.metadata    || {},
            });
        }
        persistence.clearDeadLetter();
        this._logger.info(`[InternalApiManager] ${items.length} requête(s) du dead-letter réinjectées en file`);
        return items.length;
    }

    forceSync() { return this._syncManager.forceSync(); }

    // ── Invalidation du cache ─────────────────────────────────────────────────

    _invalidateCacheForItem(item) {
        const discordId = item.metadata?.discordId;
        if (!discordId) return;

        if (item.endpoint.startsWith('/users')) {
            this.cache.invalidate('users', discordId);
            this.cache.invalidate('links', discordId);
        }
        if (item.endpoint.startsWith('/sanctions') || item.endpoint.startsWith('/moderation')) {
            this.cache.invalidate('sanctions', discordId);
        }
    }
}

// ── Singleton ─────────────────────────────────────────────────────────────────

/** @type {InternalApiManager|null} */
let _instance = null;

/**
 * Obtenir l'instance singleton.
 * Les options ne sont prises en compte qu'au premier appel.
 * @param {object} [options]
 * @returns {InternalApiManager}
 */
function getInstance(options = {}) {
    if (!_instance) _instance = new InternalApiManager(options);
    return _instance;
}

/**
 * Réinitialiser le singleton (utile pour les tests).
 */
function resetInstance() {
    _instance = null;
}

module.exports = { InternalApiManager, getInstance, resetInstance };
