/**
 * @frenchlegacy/api-client
 *
 * Point d'entrée public du package.
 *
 * Usage recommandé (singleton par service) :
 *
 *   const { getInstance } = require('@frenchlegacy/api-client');
 *   const internalApi = getInstance({
 *       baseUrl : 'http://frenchlegacy-api:10000',
 *       apiKey  : process.env.API_KEY,
 *       dataDir : '/app/data',
 *       logger  : myLogger,
 *   });
 *   await internalApi.start();
 *
 * Usage avancé (instances multiples) :
 *
 *   const { InternalApiManager } = require('@frenchlegacy/api-client');
 *   const client = new InternalApiManager({ baseUrl: '...', apiKey: '...' });
 *
 * @module @frenchlegacy/api-client
 */

'use strict';

const { InternalApiManager, getInstance, resetInstance } = require('./InternalApiManager');
const InternalApiClient  = require('./client/InternalApiClient');
const RequestQueue       = require('./queue/RequestQueue');
const QueueWorker        = require('./queue/QueueWorker');
const QueuePersistence   = require('./queue/QueuePersistence');
const LocalDataCache     = require('./cache/LocalDataCache');
const CacheSyncManager   = require('./cache/CacheSyncManager');

module.exports = {
    // Usage principal
    getInstance,
    resetInstance,
    InternalApiManager,

    // Classes individuelles (usage avancé)
    InternalApiClient,
    AuditClient: require('./client/AuditClient'),
    RequestQueue,
    QueueWorker,
    QueuePersistence,
    LocalDataCache,
    CacheSyncManager,
};
