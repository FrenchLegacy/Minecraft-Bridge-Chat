/**
 * RequestQueue - File d'attente FIFO multi-priorité
 *
 * Maintient trois sous-files (high / normal / low) en mémoire.
 * Les items haute priorité sont toujours traités avant les autres.
 * Chaque modification déclenche une sauvegarde différée via QueuePersistence.
 *
 * @author Fabien83560
 * @version 1.0.0
 * @license ISC
 */

'use strict';

const { randomUUID } = require('crypto');
const EventEmitter   = require('events');
const defaultLogger  = require('../utils/defaultLogger');

const PRIORITY_ORDER = ['high', 'normal', 'low'];

class RequestQueue extends EventEmitter {
    /**
     * @param {import('./QueuePersistence')} persistence
     * @param {object} [options]
     * @param {object} [options.logger]
     */
    constructor(persistence, options = {}) {
        super();
        this.persistence = persistence;
        this.logger      = options.logger || defaultLogger;

        /** @type {{ high: object[], normal: object[], low: object[] }} */
        this._queues   = { high: [], normal: [], low: [] };
        this._inFlight = new Map();
        this._size     = 0;
    }

    /**
     * Charger des items depuis le disque dans les sous-files (restauration après crash).
     * @param {object[]} items
     */
    load(items) {
        for (const item of items) {
            const p = PRIORITY_ORDER.includes(item.priority) ? item.priority : 'normal';
            this._queues[p].push(item);
            this._size++;
        }
        if (items.length > 0) {
            this.logger.info(
                `[RequestQueue] ${this._size} requête(s) restaurées ` +
                `(high:${this._queues.high.length} normal:${this._queues.normal.length} low:${this._queues.low.length})`
            );
        }
    }

    /**
     * Ajouter une requête en file.
     * @param {object} options
     * @param {string} options.method
     * @param {string} options.endpoint
     * @param {object|null} [options.body]
     * @param {'high'|'normal'|'low'} [options.priority='normal']
     * @param {number} [options.maxAttempts=3]
     * @param {object} [options.metadata={}]
     * @returns {string} ID de la requête
     */
    push(options) {
        const priority = PRIORITY_ORDER.includes(options.priority) ? options.priority : 'normal';

        const item = {
            id          : randomUUID(),
            method      : (options.method || 'GET').toUpperCase(),
            endpoint    : options.endpoint,
            body        : options.body ?? null,
            priority,
            createdAt   : Date.now(),
            attempts    : 0,
            maxAttempts : options.maxAttempts || 3,
            metadata    : options.metadata || {},
        };

        this._queues[priority].push(item);
        this._size++;
        if (!this.persistImmediate()) {
            this._queues[priority].pop();
            this._size--;
            throw new Error(`Impossible de persister la requête ${item.id}`);
        }

        this.logger.debug(`[RequestQueue] +1 [${priority}] ${item.method} ${item.endpoint} — id=${item.id} (total=${this._size})`);
        this.emit('enqueued', item);

        return item.id;
    }

    /** Retirer et retourner le prochain item (priorité high → normal → low). */
    shift() {
        for (const p of PRIORITY_ORDER) {
            if (this._queues[p].length > 0) {
                const item = this._queues[p].shift();
                this._inFlight.set(item.id, item);
                this._size--;
                return item;
            }
        }
        return null;
    }

    /** Confirmer définitivement un item après succès ou dead-letter persistée. */
    acknowledge(item) {
        if (!this._inFlight.delete(item.id)) return true;
        if (this.persistImmediate()) return true;

        this._inFlight.set(item.id, item);
        this.logger.error(`[RequestQueue] Impossible de confirmer la requête ${item.id}`);
        return false;
    }

    /** Remettre un item en tête de sa sous-file (retry, 429). */
    requeueItem(item) {
        this._inFlight.delete(item.id);
        const p = PRIORITY_ORDER.includes(item.priority) ? item.priority : 'normal';
        this._queues[p].unshift(item);
        this._size++;
        this._persist();
    }

    /** Consulter le prochain item sans le retirer. */
    peek() {
        for (const p of PRIORITY_ORDER) {
            if (this._queues[p].length > 0) return this._queues[p][0];
        }
        return null;
    }

    get size() { return this._size; }

    toArray() {
        return [
            ...this._queues.high,
            ...this._queues.normal,
            ...this._queues.low,
            ...this._inFlight.values(),
        ];
    }

    _persist() {
        this.persistence.savePending(this.toArray());
    }

    persistImmediate() {
        return this.persistence.savePendingImmediate(this.toArray());
    }
}

module.exports = RequestQueue;
