/**
 * QueuePersistence - Persistance de la file d'attente sur disque
 *
 * Assure la survie des requêtes en attente aux redémarrages et aux crashes.
 * Utilise l'écriture atomique (fichier temporaire + renommage) pour éviter
 * toute corruption du fichier JSON.
 *
 * @author Fabien83560
 * @version 1.0.0
 * @license ISC
 */

'use strict';

const fs            = require('fs');
const path          = require('path');
const defaultLogger = require('../utils/defaultLogger');

class QueuePersistence {
    /**
     * @param {object} [options]
     * @param {string} [options.dataDir]               - Répertoire de stockage
     * @param {number} [options.deadLetterMaxSize=500]
     * @param {number} [options.saveDebounceMs=500]
     * @param {object} [options.logger]
     */
    constructor(options = {}) {
        this.logger      = options.logger || defaultLogger;
        this.dataDir     = options.dataDir || path.join(process.cwd(), 'data', 'queue');

        this.pendingFile       = path.join(this.dataDir, 'pending.json');
        this.deadLetterFile    = path.join(this.dataDir, 'dead-letter.json');
        this.deadLetterMaxSize = options.deadLetterMaxSize || 500;
        this.saveDebounceMs    = options.saveDebounceMs    || 500;

        this._saveTimer = null;
        this._ensureDir();
    }

    _ensureDir() {
        try {
            if (!fs.existsSync(this.dataDir)) {
                fs.mkdirSync(this.dataDir, { recursive: true });
                this.logger.debug(`[QueuePersistence] Répertoire créé: ${this.dataDir}`);
            }
        } catch (err) {
            this.logger.error(`[QueuePersistence] Impossible de créer le répertoire: ${err.message}`);
        }
    }

    loadPending() {
        const items = this._readFile(this.pendingFile);
        if (items.length > 0) {
            this.logger.info(`[QueuePersistence] ${items.length} requête(s) restaurée(s) depuis pending.json`);
        }
        return items;
    }

    savePending(items) {
        if (this._saveTimer) clearTimeout(this._saveTimer);
        this._saveTimer = setTimeout(() => {
            this._saveTimer = null;
            this._atomicWrite(this.pendingFile, items);
        }, this.saveDebounceMs);
    }

    savePendingImmediate(items) {
        if (this._saveTimer) {
            clearTimeout(this._saveTimer);
            this._saveTimer = null;
        }
        return this._atomicWrite(this.pendingFile, items);
    }

    addToDeadLetter(item) {
        const items   = this._readFile(this.deadLetterFile);
        items.push({ ...item, deadAt: Date.now() });
        const trimmed = items.length > this.deadLetterMaxSize
            ? items.slice(items.length - this.deadLetterMaxSize)
            : items;
        const saved = this._atomicWrite(this.deadLetterFile, trimmed);
        this.logger.debug(`[QueuePersistence] Dead letter: ${trimmed.length} entrée(s)`);
        return saved;
    }

    loadDeadLetter()  { return this._readFile(this.deadLetterFile); }
    clearDeadLetter() { return this._atomicWrite(this.deadLetterFile, []); }

    _atomicWrite(filePath, data) {
        const tmp = filePath + '.tmp';
        try {
            fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
            fs.renameSync(tmp, filePath);
            return true;
        } catch (err) {
            this.logger.error(`[QueuePersistence] Erreur écriture atomique ${path.basename(filePath)}: ${err.message}`);
            try { fs.unlinkSync(tmp); } catch { /* ignore */ }
            return false;
        }
    }

    _readFile(filePath) {
        try {
            if (!fs.existsSync(filePath)) return [];
            const raw = fs.readFileSync(filePath, 'utf8');
            return JSON.parse(raw);
        } catch (err) {
            this.logger.warn(`[QueuePersistence] Fichier corrompu ou illisible (${path.basename(filePath)}): ${err.message}`);
            return [];
        }
    }
}

module.exports = QueuePersistence;
