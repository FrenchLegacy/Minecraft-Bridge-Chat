/**
 * QueueWorker - Consommateur de la file d'attente
 *
 * Traite les items de la RequestQueue en parallèle (max `maxConcurrency`).
 * Gère les cas d'erreur :
 *   • Succès (2xx)          → emit 'request:success'
 *   • Rate-limit (429)      → pause totale + réinsertion en tête de file
 *   • Erreur client (4xx)   → dead-letter immédiat (pas de retry)
 *   • Erreur serveur/réseau → retry avec backoff exponentiel + jitter
 *   • Max tentatives        → dead-letter
 *
 * @author Fabien83560
 * @version 1.0.0
 * @license ISC
 */

'use strict';

const EventEmitter  = require('events');
const defaultLogger = require('../utils/defaultLogger');

const withJitter = (ms) => Math.floor(ms * (0.9 + Math.random() * 0.2));

class QueueWorker extends EventEmitter {
    /**
     * @param {import('./RequestQueue')}     queue
     * @param {import('./QueuePersistence')} persistence
     * @param {import('../client/InternalApiClient')} apiClient
     * @param {object}   [options]
     * @param {number}   [options.maxConcurrency=1]
     * @param {number[]} [options.retryDelays]
     * @param {object}   [options.logger]
     */
    constructor(queue, persistence, apiClient, options = {}) {
        super();
        this.queue       = queue;
        this.persistence = persistence;
        this.apiClient   = apiClient;
        this.logger      = options.logger || defaultLogger;

        this.maxConcurrency = options.maxConcurrency || 1;
        this.retryDelays    = options.retryDelays    || [2000, 8000, 30000];

        this._running     = 0;
        this._paused      = false;
        this._pauseTimer  = null;
        this._loopRunning = false;

        this.queue.on('enqueued', () => this._tick());
    }

    start() {
        this.logger.info('[QueueWorker] Démarrage');
        this._tick();
    }

    stop() {
        this._paused = true;
        if (this._pauseTimer) {
            clearTimeout(this._pauseTimer);
            this._pauseTimer = null;
        }
        this.logger.info('[QueueWorker] Arrêt demandé — plus aucun nouvel item ne sera traité');
    }

    _tick() {
        if (this._paused || this._loopRunning) return;
        this._loopRunning = true;
        this._loop();
    }

    _loop() {
        this._loopRunning = false;
        while (!this._paused && this._running < this.maxConcurrency && this.queue.size > 0) {
            const item = this.queue.shift();
            if (!item) break;
            this._running++;
            this._processItem(item).finally(() => {
                this._running--;
                if (!this._paused && this.queue.size > 0) setImmediate(() => this._tick());
            });
        }
    }

    async _processItem(item) {
        item.attempts++;
        this.logger.debug(
            `[QueueWorker] → ${item.method} ${item.endpoint} ` +
            `(tentative ${item.attempts}/${item.maxAttempts}, id=${item.id})`
        );

        const result = await this.apiClient.request(item.method, item.endpoint, item.body);

        if (result.success) {
            this.logger.debug(`[QueueWorker] ✓ ${item.method} ${item.endpoint} [${result.status}]`);
            this.queue.acknowledge(item);
            this.emit('request:success', { item, result });
            return;
        }

        if (result.status === 429) {
            const retryAfterSec = result.data?.retryAfter ?? result.data?.['retry-after'] ?? 10;
            const pauseMs = retryAfterSec * 1000;
            this.logger.warn(`[QueueWorker] ⚠ Rate-limit 429 — pause ${pauseMs}ms avant reprise`);
            item.attempts--;
            this.queue.requeueItem(item);
            this._pauseFor(pauseMs);
            return;
        }

        if (result.status >= 400 && result.status < 500) {
            this.logger.error(
                `[QueueWorker] ✗ Erreur client ${result.status} — ${item.method} ${item.endpoint} → dead-letter`
            );
            const saved = this.persistence.addToDeadLetter({ ...item, lastError: `HTTP ${result.status}`, lastStatus: result.status });
            if (!saved) {
                this.queue.requeueItem(item);
                return;
            }
            this.queue.acknowledge(item);
            this.emit('request:dead', { item, result });
            return;
        }

        if (item.attempts < item.maxAttempts) {
            const baseDelay = this.retryDelays[item.attempts - 1] ?? this.retryDelays[this.retryDelays.length - 1];
            const delayMs   = withJitter(baseDelay);
            this.logger.warn(
                `[QueueWorker] ↻ Échec ${item.method} ${item.endpoint} ` +
                `[${result.status || 'réseau'}] — retry dans ${delayMs}ms ` +
                `(tentative ${item.attempts}/${item.maxAttempts})`
            );
            this.emit('request:retry', { item, result, delayMs });
            await new Promise((r) => setTimeout(r, delayMs));
            this.queue.requeueItem(item);
            setImmediate(() => this._tick());
        } else {
            const lastError = result.error || `HTTP ${result.status || 'réseau'}`;
            this.logger.error(`[QueueWorker] ✗ Max tentatives atteintes — ${item.method} ${item.endpoint} → dead-letter`);
            const saved = this.persistence.addToDeadLetter({ ...item, lastError, lastStatus: result.status });
            if (!saved) {
                this.queue.requeueItem(item);
                return;
            }
            this.queue.acknowledge(item);
            this.emit('request:dead', { item, result });
        }
    }

    _pauseFor(ms) {
        this._paused = true;
        if (this._pauseTimer) clearTimeout(this._pauseTimer);
        this._pauseTimer = setTimeout(() => {
            this._paused     = false;
            this._pauseTimer = null;
            this.logger.info('[QueueWorker] Reprise après rate-limit');
            this._tick();
        }, ms);
    }

    getStatus() {
        return { running: this._running, paused: this._paused, queueSize: this.queue.size };
    }
}

module.exports = QueueWorker;
