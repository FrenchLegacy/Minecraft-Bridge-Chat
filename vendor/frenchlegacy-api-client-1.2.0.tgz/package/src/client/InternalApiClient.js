/**
 * InternalApiClient - Client HTTP vers FrenchLegacy-API
 *
 * Wrapper autour des modules http/https natifs de Node.js pour envoyer des
 * requêtes authentifiées à l'API interne. Renvoie toujours un objet uniforme
 * { success, status, data, error } afin que les couches supérieures n'aient
 * pas besoin de gérer les exceptions HTTP.
 *
 * Authentification : header `x-api-key`
 *
 * @author Fabien83560
 * @version 1.0.0
 * @license ISC
 */

'use strict';

const https         = require('https');
const http          = require('http');
const defaultLogger = require('../utils/defaultLogger');

class InternalApiClient {
    /**
     * @param {object} options
     * @param {string} options.baseUrl          - URL de base (ex: "http://frenchlegacy-api:10000")
     * @param {string} [options.apiKey]         - Clé API
     * @param {number} [options.timeout=10000]  - Timeout en ms
     * @param {object} [options.logger]         - Logger injecté ({ info, warn, error, debug })
     */
    constructor(options = {}) {
        this.logger  = options.logger || defaultLogger;
        this.apiKey  = options.apiKey  || process.env.API_KEY || '';
        this.timeout = options.timeout || 10000;

        const parsed     = new URL(options.baseUrl || 'http://localhost:10000');
        this._protocol   = parsed.protocol === 'https:' ? https : http;
        this._host       = parsed.hostname;
        this._port       = parsed.port ? parseInt(parsed.port, 10) : (parsed.protocol === 'https:' ? 443 : 80);
        this._basePath   = parsed.pathname.replace(/\/+$/, '');
    }

    get(endpoint)              { return this._request('GET',    endpoint, null); }
    post(endpoint, body)       { return this._request('POST',   endpoint, body); }
    patch(endpoint, body)      { return this._request('PATCH',  endpoint, body); }
    put(endpoint, body)        { return this._request('PUT',    endpoint, body); }
    delete(endpoint, body = null) { return this._request('DELETE', endpoint, body); }

    /**
     * Point d'entrée générique — utilisé par QueueWorker.
     * @param {string}      method
     * @param {string}      endpoint
     * @param {object|null} body
     * @returns {Promise<{success:boolean, status:number, data:*, error:string|null}>}
     */
    request(method, endpoint, body = null) {
        return this._request(method.toUpperCase(), endpoint, body);
    }

    _request(method, endpoint, body) {
        return new Promise((resolve) => {
            const fullPath = this._basePath + endpoint;
            let bodyStr;
            try {
                bodyStr = body !== null && body !== undefined ? JSON.stringify(body) : null;
            } catch (err) {
                this.logger.error(`[InternalApiClient] Corps JSON invalide ${method} ${endpoint}: ${err.message}`);
                resolve({ success: false, status: 0, data: null, error: err.message });
                return;
            }

            const reqOptions = {
                hostname : this._host,
                port     : this._port,
                path     : fullPath,
                method,
                headers  : {
                    'Content-Type' : 'application/json',
                    'Accept'       : 'application/json',
                    'x-api-key'    : this.apiKey,
                },
                timeout  : this.timeout,
            };

            if (bodyStr) {
                reqOptions.headers['Content-Length'] = Buffer.byteLength(bodyStr, 'utf8');
            }

            const req = this._protocol.request(reqOptions, (res) => {
                let raw = '';
                res.on('aborted', () => resolve({ success: false, status: 0, data: null, error: 'Response interrupted' }));
                res.on('error', () => resolve({ success: false, status: 0, data: null, error: 'Response interrupted' }));
                res.on('data', (chunk) => { raw += chunk; });
                res.on('end', () => {
                    let data = null;
                    try {
                        data = raw ? JSON.parse(raw) : null;
                    } catch {
                        data = raw || null;
                    }

                    const success = res.statusCode >= 200 && res.statusCode < 300;
                    if (!success) {
                        this.logger.debug(`[InternalApiClient] ${method} ${endpoint} → HTTP ${res.statusCode}`);
                    }

                    resolve({ success, status: res.statusCode, data, error: null });
                });
            });

            req.on('timeout', () => {
                req.destroy();
                this.logger.warn(`[InternalApiClient] Timeout sur ${method} ${endpoint}`);
                resolve({ success: false, status: 0, data: null, error: 'Request timeout' });
            });

            req.on('error', (err) => {
                this.logger.warn(`[InternalApiClient] Erreur réseau ${method} ${endpoint}: ${err.message}`);
                resolve({ success: false, status: 0, data: null, error: err.message });
            });

            if (bodyStr) req.write(bodyStr, 'utf8');
            req.end();
        });
    }
}

module.exports = InternalApiClient;
