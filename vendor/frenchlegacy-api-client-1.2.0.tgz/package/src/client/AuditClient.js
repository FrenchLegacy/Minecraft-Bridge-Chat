'use strict';

const InternalApiClient = require('./InternalApiClient');

class AuditClient {
    constructor(options = {}) {
        this.client = new InternalApiClient(options);
    }

    async sendEvent(event) {
        const result = await this.client.post('/audit/events', event);
        this.confirm(result, event.eventId);
        return { accepted: true };
    }

    async sendDelivery(event, delivery) {
        const endpoint = '/audit/events/' + encodeURIComponent(event.eventId) + '/delivery';
        let result = await this.client.put(endpoint, delivery);
        if (result.status === 404) {
            // Retention may remove an old event while its local receipt is still pending.
            await this.sendEvent(event);
            result = await this.client.put(endpoint, delivery);
        }
        this.confirm(result, event.eventId);
        return { accepted: true };
    }

    confirm(result, eventId) {
        if (result.success && result.data?.accepted === true && result.data.eventId === eventId) return;
        // Never include response bodies, credentials or event content in diagnostics.
        throw new Error('Audit API delivery not acknowledged (HTTP ' + result.status + ')');
    }
}

module.exports = AuditClient;
