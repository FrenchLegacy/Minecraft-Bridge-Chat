# FrenchLegacy-ApiClient
## AuditClient

AuditClient expose sendEvent(event) et sendDelivery(event, receipt) sur les routes /audit/events authentifiées. Il utilise le client HTTP direct : la file durable du paquet logging reste seule responsable des retries. Une réponse HTTP sans accepted: true et eventId correspondant n’acquitte rien. Aucun contenu de réponse n’entre dans les erreurs du transport. Les accusés Discord-only ne doivent pas être transmis à cette API.
