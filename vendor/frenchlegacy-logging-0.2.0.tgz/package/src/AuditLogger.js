'use strict';

const path = require('path');
const { randomUUID } = require('crypto');
const Outbox = require('./Outbox');
const resolveForumPost = require('./forum');
const { normalizeEvent, databaseEvent, destinations, formatMessage, redact } = require('./events');

class AuditLogger {
    constructor({ source, config = {}, getClient, dataDir, logger = console, secrets = [], databaseSender, databaseDeliverySender }) {
        if (!['discord', 'bridge', 'event'].includes(source)) throw new Error('Invalid audit source');
        this.source = source;
        this.instanceId = randomUUID();
        this.config = config;
        this.getClient = getClient;
        this.logger = logger;
        this.secrets = secrets;
        this.databaseSender = databaseSender;
        this.databaseDeliverySender = databaseDeliverySender;
        this.outbox = null;
        this.running = null;
        this.lastDiagnostic = 0;
        this.receipts = new Map();
        this.receiptWaiters = new Map();
        if (config.enabled !== true) return;
        this.outbox = new Outbox(path.join(dataDir, 'audit'), config.maxBytes);
        this.start();
    }

    start() {
        if (!this.outbox || this.timer) return;
        this.timer = setInterval(() => this.flush().catch(error => this.diagnostic(error)), 5000);
        this.timer.unref();
        this.flush().catch(error => this.diagnostic(error));
    }

    diagnostic(error) {
        if (Date.now() - this.lastDiagnostic < 60000) return;
        this.lastDiagnostic = Date.now();
        this.logger.error('[Audit] ' + redact(error.message, this.secrets).slice(0, 250));
    }

    async publish(input) {
        if (!this.outbox) return { accepted: false, reason: 'disabled' };
        try {
            const event = normalizeEvent(input, this.source, this.secrets);
            event.instanceId = this.instanceId;
            event.environment = ['production', 'staging', 'test', 'development'].includes(this.config.environment)
                ? this.config.environment : 'unknown';
            const pending = destinations(event);
            if (!pending.length) return { accepted: false, reason: 'filtered' };
            if (this.databaseDeliverySender && pending.includes('database') && pending.includes('discord')) pending.push('delivery');
            const record = { event, pending, deliveries: {}, attempts: {}, retryAt: {} };
            this.outbox.save(record);
            if (this.outbox.bytes >= this.outbox.maxBytes * 0.8) this.diagnostic(new Error('Audit outbox above 80% capacity'));
            this.flush().catch(error => this.diagnostic(error));
            return { accepted: true, eventId: event.eventId };
        } catch (error) {
            this.diagnostic(error);
            return { accepted: false, reason: 'persistence_failed' };
        }
    }

    async publishAndWait(input) {
        const result = await this.publish(input);
        if (!result.accepted) return null;
        const confirmed = this.receipts.get(result.eventId);
        if (confirmed) return { ...result, id: confirmed.messageId, channelId: confirmed.postId };
        // Moderation callers need the Discord link, not a potentially slow database retry.
        const receipt = await new Promise(resolve => {
            const timer = setTimeout(() => {
                this.receiptWaiters.delete(result.eventId);
                resolve(null);
            }, 2000);
            this.receiptWaiters.set(result.eventId, value => {
                clearTimeout(timer);
                resolve(value);
            });
            this.flush().then(() => this.flush()).catch(error => this.diagnostic(error));
        });
        return { ...result, id: receipt?.messageId || null, channelId: receipt?.postId || null };
    }

    flush(options = {}) {
        if (!this.outbox) return Promise.resolve();
        if (this.running) {
            return options.force ? this.running.then(() => this.flush(options)) : this.running;
        }
        this.running = this.deliver(options).finally(() => { this.running = null; });
        return this.running;
    }

    async deliver({ force = false } = {}) {
        for (const record of this.outbox.records.values()) {
            if (!record.pending.length) this.outbox.remove(record.event.eventId);
        }
        const ready = [...this.outbox.records.values()].filter(record =>
            record.pending.some(destination => (destination !== 'delivery' || record.deliveries.database)
                && (force || !(record.retryAt[destination] > Date.now()))));
        for (const original of ready.slice(0, 100)) {
            let record = original;
            for (const destination of [...record.pending]) {
                if (destination === 'delivery' && !record.deliveries.database) continue;
                if (!force && record.retryAt[destination] > Date.now()) continue;
                try {
                    let receipt;
                    if (destination === 'discord') {
                        const post = await resolveForumPost(this.getClient(), this.config.posts?.[record.event.category]);
                        const message = await post.send(formatMessage(record.event));
                        receipt = { messageId: message.id, postId: post.id, deliveredAt: new Date().toISOString() };
                    } else if (destination === 'database') {
                        if (!this.databaseSender) throw new Error('Audit database delivery not configured');
                        const response = await this.databaseSender(databaseEvent(record.event));
                        if (response?.accepted !== true) throw new Error('Audit database delivery not acknowledged');
                        receipt = { accepted: true };
                    } else if (destination === 'delivery') {
                        const response = await this.databaseDeliverySender(databaseEvent(record.event), this.deliveryState(record));
                        if (response?.accepted !== true) throw new Error('Audit receipt not acknowledged');
                        receipt = { accepted: true };
                    } else {
                        throw new Error('Invalid audit destination');
                    }
                    const next = {
                        ...record,
                        pending: record.pending.filter(value => value !== destination),
                        deliveries: { ...record.deliveries, [destination]: receipt }
                    };
                    // Once Discord acknowledged delivery, its body no longer needs to wait for the database.
                    if (destination === 'discord') {
                        next.event = { ...record.event, display: { title: '', description: '', fields: [] } };
                        this.queueDelivery(next);
                    }
                    this.outbox.save(next);
                    if (destination === 'discord') {
                        this.receipts.set(record.event.eventId, receipt);
                        this.receiptWaiters.get(record.event.eventId)?.(receipt);
                        this.receiptWaiters.delete(record.event.eventId);
                        if (this.receipts.size > 256) this.receipts.delete(this.receipts.keys().next().value);
                    }
                    record = next;
                } catch (error) {
                    const attempt = (record.attempts[destination] || 0) + 1;
                    const next = {
                        ...record, attempts: { ...record.attempts, [destination]: attempt },
                        retryAt: { ...record.retryAt, [destination]: Date.now() + Math.min(300000, 5000 * 2 ** Math.min(attempt, 6)) }
                    };
                    if (destination === 'discord') this.queueDelivery(next);
                    this.outbox.save(next);
                    record = next;
                    this.diagnostic(error);
                }
            }
            if (!record.pending.length) this.outbox.remove(record.event.eventId);
        }
    }

    queueDelivery(record) {
        if (!this.databaseDeliverySender || !databaseEvent(record.event)) return;
        record.pending = [...record.pending];
        if (!record.pending.includes('delivery')) record.pending.push('delivery');
        record.retryAt = { ...record.retryAt, delivery: 0 };
    }

    deliveryState(record) {
        const receipt = record.deliveries.discord;
        const configured = String(this.config.posts?.[record.event.category] || '');
        const postId = receipt?.postId || configured.match(/^(?:<#)?(\d{17,20})>?$/)?.[1] || null;
        return {
            state: receipt ? 'delivered' : record.attempts.discord ? 'retrying' : 'pending',
            attempts: (record.attempts.discord || 0) + (receipt ? 1 : 0),
            nextRetryAt: !receipt && record.retryAt.discord ? new Date(record.retryAt.discord).toISOString() : null,
            errorCode: !receipt && record.attempts.discord ? 'DISCORD_DELIVERY_FAILED' : null,
            deliveredAt: receipt?.deliveredAt || null, messageId: receipt?.messageId || null, postId
        };
    }

    async trackCommand(interaction, execute) {
        const correlationId = interaction.id || randomUUID();
        let subcommand;
        try { subcommand = interaction.options?.getSubcommand(false); } catch {}
        const base = {
            category: 'commandes', command: interaction.commandName, subcommand, correlationId,
            interactionId: interaction.id, actorId: interaction.user?.id, discordGuildId: interaction.guildId,
            channelId: interaction.channelId, origin: interaction.commandOrigin || (interaction.user?.bot ? 'bot' : 'human'),
            title: '/' + interaction.commandName + (subcommand ? ' ' + subcommand : '')
        };
        const started = Date.now();
        await this.publish({ ...base, eventType: 'command.received', status: 'unknown' });
        try {
            const result = await execute();
            await this.publish({ ...base, eventType: 'command.result', status: result?.status || 'unknown', context: { durationMs: Date.now() - started } });
            return result;
        } catch (error) {
            await this.publish({ ...base, eventType: 'command.result', status: 'failed', context: { durationMs: Date.now() - started } });
            throw error;
        }
    }

    close() {
        clearInterval(this.timer);
        this.timer = null;
        for (const resolve of this.receiptWaiters.values()) resolve(null);
        this.receiptWaiters.clear();
        return this.running || Promise.resolve();
    }
}

module.exports = AuditLogger;
