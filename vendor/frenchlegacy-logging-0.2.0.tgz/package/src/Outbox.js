'use strict';

const fs = require('fs');
const path = require('path');

class Outbox {
    constructor(directory, maxBytes = 25 * 1024 * 1024) {
        if (!Number.isSafeInteger(maxBytes) || maxBytes <= 0) throw new Error('Invalid audit outbox quota');
        this.directory = directory;
        this.maxBytes = Math.min(maxBytes, 25 * 1024 * 1024);
        this.records = new Map();
        this.bytes = 0;
        fs.mkdirSync(directory, { recursive: true, mode: 0o700 });
        for (const name of fs.readdirSync(directory)) {
            const filename = path.join(directory, name);
            this.bytes += fs.statSync(filename).size;
            if (!name.endsWith('.json')) continue;
            if (fs.statSync(filename).size > 64 * 1024) throw new Error('Oversized audit outbox record');
            // Stop on corruption: treating a broken file as an empty queue would hide a loss.
            const record = JSON.parse(fs.readFileSync(filename, 'utf8'));
            if (name !== record.event?.eventId + '.json' || !Array.isArray(record.pending)) {
                throw new Error('Invalid audit outbox record');
            }
            this.records.set(record.event.eventId, record);
        }
    }

    save(record) {
        const id = record.event.eventId;
        if (!/^[0-9a-f-]{36}$/.test(id)) throw new Error('Invalid audit event ID');
        const filename = path.join(this.directory, id + '.json');
        const temporary = filename + '.tmp';
        const data = JSON.stringify(record);
        const size = Buffer.byteLength(data);
        const previous = fs.existsSync(filename) ? fs.statSync(filename).size : 0;
        const abandoned = fs.existsSync(temporary) ? fs.statSync(temporary).size : 0;
        const reserved = (this.records.size + (previous ? 0 : 1)) * 1024;
        if (size > 64 * 1024 || this.bytes - previous - abandoned + size + reserved > this.maxBytes) {
            throw new Error('Audit outbox quota reached');
        }
        if (!previous && this.records.size >= 10000) throw new Error('Audit outbox item limit reached');
        let fd;
        try {
            fd = fs.openSync(temporary, 'w', 0o600);
            fs.writeFileSync(fd, data);
            fs.fsyncSync(fd);
            fs.closeSync(fd);
            fd = undefined;
            fs.renameSync(temporary, filename);
        } finally {
            if (fd !== undefined) fs.closeSync(fd);
            if (fs.existsSync(temporary)) fs.unlinkSync(temporary);
            this.bytes -= abandoned;
        }
        this.bytes += size - previous;
        this.records.set(id, record);
    }

    remove(id) {
        const filename = path.join(this.directory, id + '.json');
        const size = fs.statSync(filename).size;
        fs.unlinkSync(filename);
        this.bytes -= size;
        this.records.delete(id);
    }
}

module.exports = Outbox;
