'use strict';

async function resolveForumPost(client, postId) {
    const id = String(postId || '').replace(/^<#(\d+)>$/, '$1').trim();
    if (!/^\d{17,20}$/.test(id)) throw new Error('Audit forum post ID missing or invalid');
    if (!client?.isReady()) throw new Error('Discord not ready for audit delivery');
    const thread = await client.channels.fetch(id);
    if (!thread?.isThread?.()) throw new Error('Audit destination is not a thread');
    const parent = thread.parent || await client.channels.fetch(thread.parentId);
    if (parent?.type !== 15) throw new Error('Audit thread is not a forum post');
    if (thread.locked) throw new Error('Audit forum post is locked');
    const permissions = thread.permissionsFor(client.user);
    for (const permission of ['ViewChannel', 'SendMessagesInThreads', 'EmbedLinks', 'ReadMessageHistory']) {
        if (!permissions?.has(permission)) throw new Error('Missing audit permission: ' + permission);
    }
    if (thread.archived) {
        if (!permissions.has('ManageThreads')) throw new Error('Missing audit permission: ManageThreads');
        await thread.setArchived(false);
    }
    return thread;
}

module.exports = resolveForumPost;
