'use strict';

const AuditLogger = require('./AuditLogger');
const instances = new WeakMap();

function getAuditLogger(client, options) {
    if (!instances.has(client)) instances.set(client, new AuditLogger({ ...options, getClient: () => client }));
    return instances.get(client);
}

function collectSecrets(config) {
    const secrets = ['app.token', 'internalApi.apiKey', 'internalApi.discordApi', 'discord.token']
        .map(key => config.get(key)).filter(value => typeof value === 'string');
    for (const entry of config.get('hypixel.apiKeys', []) || []) {
        if (typeof entry.key === 'string') secrets.push(entry.key);
    }
    return secrets;
}

module.exports = { AuditLogger, getAuditLogger, collectSecrets, ...require('./events') };
