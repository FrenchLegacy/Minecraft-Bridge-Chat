'use strict';

const { randomUUID } = require('crypto');

const categories = [
    'commandes', 'sanctions', 'messages', 'membres', 'roles', 'verification', 'guildes',
    'connexions-jeu', 'xp', 'tickets', 'carries', 'giveaways', 'events', 'prives',
    'technique', 'statut-bots', 'archive-candidatures', 'archive-tickets',
    'archive-commissions', 'archive-carriers'
];
const statuses = ['success', 'denied', 'invalid', 'failed', 'timeout', 'sent', 'partial', 'unknown'];
const discordOnly = new Set(['connexions-jeu', 'xp', 'prives', ...categories.filter(value => value.startsWith('archive-'))]);
const secretKey = /token|password|passwd|secret|authorization|cookie|api.?key|discordapi|private.?key/i;

function redact(value, secrets = []) {
    let text = String(value ?? '');
    for (const secret of secrets) {
        if (typeof secret === 'string' && secret.length >= 8) text = text.replaceAll(secret, '[REDACTED]');
    }
    return text
        .replace(/https?:\/\/(?:(?:canary|ptb)\.)?discord(?:app)?\.com\/api(?:\/v\d+)?\/webhooks\/[^\s<>)"']+/gi, '[REDACTED_WEBHOOK]')
        .replace(/\bBearer\s+[A-Za-z0-9._~+/-]+=*/gi, 'Bearer [REDACTED]')
        .replace(/((?:token|password|passwd|secret|api[_-]?key|authorization|discordapi)["']?\s*[:=]\s*)(?:"[^"]*"|'[^']*'|[^\s,;]+)/gi, '$1[REDACTED]')
        .replace(/\b(?:mfa\.[\w-]{20,}|[\w-]{23,28}\.[\w-]{6}\.[\w-]{27,}|eyJ[\w-]+\.[\w-]+\.[\w-]+)\b/g, '[REDACTED]');
}

function sanitize(value, secrets = [], depth = 0, seen = new Set()) {
    if (value === null || value === undefined) return null;
    if (typeof value === 'string') return redact(value, secrets).slice(0, 4000);
    if (typeof value === 'number') return Number.isFinite(value) ? value : null;
    if (typeof value === 'boolean') return value;
    if (typeof value !== 'object' || depth >= 5 || seen.has(value)) return '[OMITTED]';
    seen.add(value);
    if (Array.isArray(value)) return value.slice(0, 50).map(item => sanitize(item, secrets, depth + 1, seen));
    return Object.fromEntries(Object.entries(value).slice(0, 50).map(([key, item]) => [
        key.slice(0, 80),
        secretKey.test(key) || (key === 'value' && secretKey.test(value.name || ''))
            ? '[REDACTED]' : sanitize(item, secrets, depth + 1, seen)
    ]));
}

function normalizeEvent(input, source, secrets = []) {
    if (!categories.includes(input.category)) throw new Error('Unknown audit category');
    if (!/^[a-z][a-z0-9._-]{1,79}$/.test(input.eventType || '')) throw new Error('Invalid audit event type');
    const clean = sanitize(input, secrets);
    const event = {
        eventId: randomUUID(), schemaVersion: 1, source,
        occurredAt: new Date().toISOString(), eventType: input.eventType, category: input.category,
        status: statuses.includes(input.status) ? input.status : 'unknown',
        origin: ['human', 'bot', 'automatic', 'system'].includes(input.origin) ? input.origin : 'unknown'
    };
    for (const key of ['actorId', 'targetId', 'discordGuildId', 'minecraftGuildId', 'channelId', 'interactionId', 'correlationId']) {
        if (typeof clean[key] === 'string') event[key] = clean[key].slice(0, 100);
    }
    for (const key of ['command', 'subcommand']) {
        if (typeof clean[key] === 'string' && /^[\p{L}\p{N}_-]{1,64}$/u.test(clean[key])) event[key] = clean[key];
    }
    event.display = {
        title: String(clean.title || input.eventType).slice(0, 180),
        description: typeof clean.description === 'string' ? clean.description : '',
        fields: Array.isArray(clean.fields) ? clean.fields.filter(field => field && typeof field.name === 'string' && field.value != null)
            .slice(0, 20).map(field => ({ name: field.name.slice(0, 80), value: String(field.value).slice(0, 1024) })) : []
    };
    event.context = {};
    // No free-form metadata or message body enters the database projection.
    for (const key of ['messageId', 'entityId', 'requestedCount', 'deletedCount', 'durationMs']) {
        if (typeof clean.context?.[key] === 'string' || typeof clean.context?.[key] === 'number') {
            event.context[key] = clean.context[key];
        }
    }
    return event;
}

function databaseEvent(event) {
    if (discordOnly.has(event.category)) return null;
    const { display, ...stored } = event;
    return stored;
}

function destinations(event) {
    if (event.origin === 'automatic' || event.eventType === 'guild.chat' || event.eventType === 'guild.online') return [];
    if (event.eventType === 'giveaway.participated') return ['database'];
    return databaseEvent(event) ? ['discord', 'database'] : ['discord'];
}

function formatMessage(event) {
    const colors = { success: 0x2ECC71, failed: 0xE74C3C, denied: 0xE67E22, invalid: 0xE67E22, timeout: 0xF1C40F, sent: 0x3498DB };
    const embed = {
        title: event.display.title, description: event.display.description || undefined,
        color: colors[event.status] || 0x95A5A6, timestamp: event.occurredAt,
        footer: { text: event.source + ' • ' + event.eventType + ' • ' + event.eventId }, fields: []
    };
    const fields = [
        { name: 'Résultat', value: event.status },
        ...(event.actorId ? [{ name: 'Acteur', value: event.actorId }] : []),
        ...(event.targetId ? [{ name: 'Cible', value: event.targetId }] : []),
        ...(event.correlationId ? [{ name: 'Corrélation', value: event.correlationId }] : []),
        ...event.display.fields
    ];
    let available = 5900 - embed.title.length - (embed.description?.length || 0) - embed.footer.text.length;
    for (const field of fields.slice(0, 25)) {
        const name = String(field.name || 'Détail').slice(0, 80);
        const value = String(field.value || '—').slice(0, Math.min(1024, available - name.length));
        if (available <= name.length || !value) break;
        embed.fields.push({ name, value, inline: false });
        available -= name.length + value.length;
    }
    return { embeds: [embed], allowedMentions: { parse: [], repliedUser: false } };
}

module.exports = { categories, statuses, redact, sanitize, normalizeEvent, databaseEvent, destinations, formatMessage };
