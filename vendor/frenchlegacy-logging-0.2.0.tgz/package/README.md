# @frenchlegacy/logging

Paquet CommonJS partagé par les trois bots. Node 22+, aucune dépendance supplémentaire.

## Contrat

- Événement validé, identifiant UUID, source, instance, environnement, date, statut et catégorie.
- Secrets connus de la configuration et motifs usuels masqués avant écriture.
- Format Discord uniforme et mentions neutralisées.
- Destination : ID d’un post existant dont le parent est un forum ; pas de création automatique.
- Post archivé : réouverture après contrôle des droits. Post verrouillé, absent ou inaccessible : livraison conservée.
- Écriture atomique avec synchronisation du fichier avant acceptation. File locale limitée à 25 Mio et 10 000 événements ; enregistrements limités à 64 Kio.
- Reprise au démarrage et toutes les cinq secondes, un seul travailleur, lots de 100 et backoff jusqu’à cinq minutes par destination.
- Accusés séparés Discord/BDD. Le contenu d’affichage est retiré après livraison Discord, même si la BDD est en panne.
- DM, connexions en jeu, XP et archives : aucun envoi vers la BDD. Messages modifiés/supprimés : uniquement identifiants et contexte autorisé dans la projection BDD.
- Commandes automatiques, chat de guilde et liste des joueurs en ligne filtrés. Un retour de handler sans statut reste inconnu.

publish() renvoie accepted: true après persistance, pas après livraison. Un refus explicite porte reason: disabled, filtered ou persistence_failed. Une erreur de configuration, validation, quota ou disque ne devient jamais un faux succès.

publishAndWait() tente aussi la livraison et renvoie les IDs Discord quand un accusé est disponible ; sinon ils restent nuls. Cette méthode conserve le contrat des anciens appels qui attachent le message de log à une sanction.

trackCommand(interaction, execute) enregistre réception et résultat avec la même corrélation. Il conserve la valeur de retour et les exceptions métier. Une erreur de persistance est signalée localement ; elle ne relance pas l’action métier.

## Intégration progressive

Le bloc audit devient autoritaire dès qu’il existe. audit.enabled: false coupe ce chemin sans retomber sur les anciens salons. Sans bloc audit, les adaptateurs des bots conservent le fonctionnement antérieur.

Renseigner audit.posts avec les IDs des posts de forum, puis activer seulement après recette. Les fichiers d’exemple livrés gardent ce mode désactivé ; aucun vrai fichier de settings n’est modifié.

Le callback optionnel databaseSender(event) doit confirmer { accepted: true } seulement après stockage idempotent par event.eventId. Le transport AuditClient utilise les routes authentifiées /audit/events. L’acceptation n’est confirmée qu’après stockage idempotent par l’API. Le callback databaseDeliverySender(event, delivery) confirme séparément les accusés Discord en BDD. Les deux restent dans la même file locale jusqu’à leur acquittement. Préparer les tables et les clés API, puis effectuer la recette avant activation.

Le vieux DiscordLogger transmet encore ses titres et champs via un adaptateur. Les événements métier structurés, références de sanctions, résumés XP, archives et journalisation exhaustive des boutons/formulaires restent à migrer. Les fichiers techniques actuels restent gérés par les loggers existants.

## Limites de livraison

Un crash après envoi Discord mais avant sauvegarde de l’accusé peut produire un doublon à la reprise. La BDD doit dédupliquer avec l’UUID ; aucune garantie « exactement une fois » sur Discord. L’écriture synchronisée protège les événements acceptés contre un arrêt du processus ; une panne matérielle/disque sort de cette garantie.

Un fichier illisible dans la file bloque son chargement et reste sur disque pour inspection. Pas d’effacement silencieux ni d’archive automatique du contenu sensible. Les diagnostics sont locaux, limités à un par minute ; le regroupement des incidents dans le post technique reste à compléter.

Le rendu respecte les limites d’un embed : les détails trop longs sont bornés. Il ne remplace pas un transcript ou une archive intégrale des pièces jointes. Les DM transmettent texte et liens de pièces jointes, sans télécharger les fichiers.

## Distribution locale

Les bots consomment le même fichier vendor/frenchlegacy-logging-0.2.0.tgz via une dépendance file:. Chaque Dockerfile le copie avant l’installation des paquets ; aucun registre privé supplémentaire ni publication nécessaire.

Source à maintenir : ce dossier. Après modification, incrémenter la version, lancer les tests, générer l’archive avec pnpm pack, puis mettre à jour l’archive, la dépendance et le verrou npm dans les consommateurs. Ne pas éditer trois copies du code partagé.

Tests : node --test test/*.test.js.

Références : [threads et permissions Discord](https://docs.discord.com/developers/topics/threads), [limites des messages](https://docs.discord.com/developers/resources/message), [dépendances locales npm](https://docs.npmjs.com/cli/v11/configuring-npm/package-json/).
