'use strict';

const AuditLogger = require('./AuditLogger');
const { createHttpSenders } = require('./transport');
const instances = new WeakMap();

function getAuditLogger(client, options) {
    if (!instances.has(client)) instances.set(client, new AuditLogger({ ...options, getClient: () => client }));
    return instances.get(client);
}

// Clés secrètes des trois bots (relevées dans leurs settings.json). Leurs
// valeurs sont masquées mot pour mot avant toute écriture, en plus des motifs
// génériques de redact(). Une clé absente d'un bot est simplement ignorée.
const SECRET_KEYS = [
    'app.token', 'discord.token',
    'internalApi.apiKey', 'internalApi.discordApi',
    'audit.apiKey',
    'features.scamListCheck.mongoUri',
    'bridge.channels.chat.webhookUrl', 'bridge.channels.staff.webhookUrl'
];
const SECRET_KEY_LISTS = ['hypixel.apiKeys', 'hypixel.linkApiKeys', 'hypixel.regularApiKeys'];

function collectSecrets(config) {
    const secrets = SECRET_KEYS.map(key => config.get(key)).filter(value => typeof value === 'string');
    for (const list of SECRET_KEY_LISTS) {
        for (const entry of config.get(list, []) || []) {
            if (typeof entry?.key === 'string') secrets.push(entry.key);
        }
    }
    return secrets;
}

module.exports = {
    AuditLogger, getAuditLogger, collectSecrets, createHttpSenders,
    setOutcome: AuditLogger.setOutcome,
    ...require('./events')
};
