'use strict';

const { randomUUID } = require('crypto');

// Taxonomie unique, partagée avec la table log_category de frenchlegacy_logs
// (migration/logs, décision M21) : mêmes codes pour l'historique et le direct.
// Une catégorie ajoutée ici doit l'être aussi dans build_sql.js (CATEGORIES_DIRECT),
// sinon l'API la refuse.
const categories = [
    'commandes', 'sanctions', 'messages', 'membres', 'roles', 'salons', 'verification', 'serveur',
    'guildes', 'connexions-jeu', 'xp', 'tickets', 'carries', 'economie', 'giveaways',
    'events', 'vocal', 'prives', 'technique', 'statut-bots', 'archive-candidature',
    'archive-ticket', 'archive-commissions', 'archive-carrier'
];
const statuses = ['success', 'denied', 'invalid', 'failed', 'timeout', 'sent', 'partial', 'unknown'];
// Jamais en base : les MP (vie privée). Les archives de tickets y vont : seule
// leur projection sans texte est stockée (M19).
const discordOnly = new Set(['prives']);
// Jamais sur Discord (décision du 30/09) : l'XP et les connexions en jeu, trop
// nombreuses pour un forum, vont en base seulement.
const databaseOnly = new Set(['connexions-jeu', 'xp']);
const secretKey = /token|password|passwd|secret|authorization|cookie|api.?key|discordapi|private.?key/i;
const SNOWFLAKE = /^\d{17,20}$/;

/**
 * Liste blanche typée du `context` (PLAN_DONNEES §1.3), partagée avec l'API
 * (normalize.js doit appliquer la même). Toute autre clé est jetée, comme toute
 * valeur du mauvais type. Types :
 *   id        chaîne non vide ≤ max, ou entier ≥ 0 (clés historiques)
 *   integer   entier sûr ≥ min (une chaîne de chiffres est convertie) ; round : un
 *             nombre décimal est arrondi (durées en ms)
 *   text      texte libre, expurgé par redact(), tronqué à max
 *   string    code ou identifiant, expurgé, JETÉ au-delà de max (tronquer le fausserait)
 *   enum      une des valeurs de values
 *   snowflake identifiant Discord (17 à 20 chiffres)
 *   date      ISO 8601 (ou Date), renvoyé en ISO UTC
 *   url       https://…, ≤ max, jetée au-delà
 *   uuid      UUID Minecraft, 32 ou 36 caractères hexadécimaux, en minuscules
 */
const CONTEXT_SCHEMA = Object.freeze({
    messageId: { type: 'id', max: 100 },
    entityId: { type: 'id', max: 100 },
    requestedCount: { type: 'integer', min: 0 },
    deletedCount: { type: 'integer', min: 0 },
    durationMs: { type: 'integer', min: 0, round: true },
    reason: { type: 'text', max: 300 },
    sanctionDurationMs: { type: 'integer', min: 0, round: true },
    expiresAt: { type: 'date' },
    targetType: {
        type: 'enum', values: ['channel', 'role', 'webhook', 'automod_rule', 'scheduled_event', 'emoji', 'sticker',
            'invite', 'integration', 'thread', 'guild', 'user', 'message', 'stage', 'soundboard', 'command']
    },
    targetEntityId: { type: 'snowflake' },
    targetName: { type: 'text', max: 100 },
    roleAction: { type: 'enum', values: ['add', 'remove'] },
    voiceAction: { type: 'enum', values: ['mute', 'unmute', 'deafen', 'undeafen', 'move', 'disconnect'] },
    fromChannelId: { type: 'snowflake' },
    toChannelId: { type: 'snowflake' },
    oldName: { type: 'text', max: 100 },
    newName: { type: 'text', max: 100 },
    level: { type: 'integer', min: 0 },
    ticketType: { type: 'string', max: 32 },
    ticketVariant: { type: 'string', max: 32 },
    transcriptUrl: { type: 'url', max: 300 },
    errorCode: { type: 'string', max: 48 },
    errorClass: { type: 'string', max: 64 },
    // Message d'erreur applicatif, jamais le message d'un utilisateur.
    errorMessage: { type: 'text', max: 300 },
    stage: { type: 'enum', values: ['received', 'sent', 'response'] },
    minecraftUuid: { type: 'uuid' },
    relatedEventId: { type: 'string', max: 64 },
    count: { type: 'integer', min: 0 }
});

function redact(value, secrets = []) {
    let text = String(value ?? '');
    for (const secret of secrets) {
        if (typeof secret === 'string' && secret.length >= 8) text = text.replaceAll(secret, '[REDACTED]');
    }
    return text
        .replace(/https?:\/\/(?:(?:canary|ptb)\.)?discord(?:app)?\.com\/api(?:\/v\d+)?\/webhooks\/[^\s<>)"']+/gi, '[REDACTED_WEBHOOK]')
        .replace(/\bBearer\s+[A-Za-z0-9._~+/-]+=*/gi, 'Bearer [REDACTED]')
        .replace(/\b((?:mongodb(?:\+srv)?|mysql|postgres(?:ql)?|redis):\/\/)[^\s@/]+@/gi, '$1[REDACTED]@')
        .replace(/((?:token|password|passwd|secret|api[_-]?key|authorization|discordapi)["']?\s*[:=]\s*)(?:"[^"]*"|'[^']*'|[^\s,;]+)/gi, '$1[REDACTED]')
        .replace(/\b(?:mfa\.[\w-]{20,}|[\w-]{23,28}\.[\w-]{6}\.[\w-]{27,}|eyJ[\w-]+\.[\w-]+\.[\w-]+)\b/g, '[REDACTED]');
}

function sanitize(value, secrets = [], depth = 0, seen = new Set()) {
    if (value === null || value === undefined) return null;
    if (typeof value === 'string') return redact(value, secrets).slice(0, 4000);
    if (typeof value === 'number') return Number.isFinite(value) ? value : null;
    if (typeof value === 'boolean') return value;
    if (typeof value !== 'object' || depth >= 5 || seen.has(value)) return '[OMITTED]';
    seen.add(value);
    if (Array.isArray(value)) return value.slice(0, 50).map(item => sanitize(item, secrets, depth + 1, seen));
    return Object.fromEntries(Object.entries(value).slice(0, 50).map(([key, item]) => [
        key.slice(0, 80),
        secretKey.test(key) || (key === 'value' && secretKey.test(value.name || ''))
            ? '[REDACTED]' : sanitize(item, secrets, depth + 1, seen)
    ]));
}

const ISO_DATE = /^\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d{1,9})?)?(?:Z|[+-]\d{2}:?\d{2})?)?$/;
const MINECRAFT_UUID = /^(?:[0-9a-f]{32}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i;

/** Valeur conforme à sa règle de CONTEXT_SCHEMA, sinon undefined (la clé est alors jetée). */
function validateContextValue(rule, value, secrets = []) {
    const text = () => (typeof value === 'string' ? redact(value, secrets).trim() : '');
    switch (rule.type) {
        case 'id':
            if (Number.isSafeInteger(value) && value >= 0) return value;
            return text() && text().length <= rule.max ? text() : undefined;
        case 'integer': {
            let number = typeof value === 'string' && /^\d{1,15}$/.test(value) ? Number(value) : value;
            if (rule.round && typeof number === 'number' && Number.isFinite(number)) number = Math.round(number);
            return Number.isSafeInteger(number) && number >= (rule.min ?? -Infinity) ? number : undefined;
        }
        case 'text':
            return text() ? text().slice(0, rule.max) : undefined;
        case 'string': {
            const clean = typeof value === 'number' && Number.isSafeInteger(value) ? String(value) : text();
            return clean && clean.length <= rule.max ? clean : undefined;
        }
        case 'enum':
            return rule.values.includes(value) ? value : undefined;
        case 'snowflake':
            return typeof value === 'string' && SNOWFLAKE.test(value) ? value : undefined;
        case 'date': {
            const time = value instanceof Date ? value.getTime()
                : typeof value === 'string' && ISO_DATE.test(value) ? Date.parse(value) : NaN;
            return Number.isFinite(time) ? new Date(time).toISOString() : undefined;
        }
        case 'url':
            if (typeof value !== 'string' || value.length > rule.max || !/^https:\/\/\S+$/.test(value)) return undefined;
            try { return new URL(value).protocol === 'https:' ? value : undefined; } catch { return undefined; }
        case 'uuid':
            return typeof value === 'string' && MINECRAFT_UUID.test(value) ? value.toLowerCase() : undefined;
        default:
            return undefined;
    }
}

/**
 * Projette un `context` libre sur la liste blanche : clés connues et valeurs du
 * bon type seulement. Aucun texte de message ni métadonnée libre n'en sort (M19).
 */
function pickContext(context, secrets = []) {
    const picked = {};
    if (!context || typeof context !== 'object' || Array.isArray(context)) return picked;
    for (const [key, rule] of Object.entries(CONTEXT_SCHEMA)) {
        if (!Object.prototype.hasOwnProperty.call(context, key)) continue;
        const value = validateContextValue(rule, context[key], secrets);
        if (value !== undefined) picked[key] = value;
    }
    return picked;
}

const NETWORK_CODES = new Set(['ECONNRESET', 'ECONNREFUSED', 'ECONNABORTED', 'ETIMEDOUT', 'ENOTFOUND', 'EAI_AGAIN',
    'EPIPE', 'EHOSTUNREACH', 'ENETUNREACH', 'ENETDOWN', 'ESOCKETTIMEDOUT']);

function isNetworkError(error) {
    if (!error || typeof error !== 'object') return false;
    if (typeof error.code === 'string' && (NETWORK_CODES.has(error.code) || error.code.startsWith('UND_ERR_'))) return true;
    if (['AbortError', 'TimeoutError', 'ConnectTimeoutError', 'SocketError'].includes(error.name)) return true;
    return /fetch failed|socket hang up|handshake has timed out/i.test(String(error.message || ''));
}

/**
 * Cause réelle d'un échec d'envoi Discord (PLAN_DONNEES §1.4), dans l'ordre :
 * code posé par forum.js, code de l'API Discord (DiscordAPIError.code, ex.
 * DISCORD_50013), statut HTTP (HTTPError.status, ex. DISCORD_503), limite de
 * débit (RateLimitError → DISCORD_429), panne réseau, sinon DISCORD_UNKNOWN.
 */
function discordErrorCode(error) {
    if (typeof error?.auditCode === 'string') return error.auditCode;
    // Code 0 = « General error » de Discord : le statut HTTP en dit plus.
    if (/^\d{1,6}$/.test(String(error?.code ?? '')) && Number(error.code) > 0) return 'DISCORD_' + Number(error.code);
    if (Number.isInteger(error?.status) && error.status >= 400 && error.status <= 599) return 'DISCORD_' + error.status;
    if (error?.name === 'RateLimitError' || error?.constructor?.name === 'RateLimitError') return 'DISCORD_429';
    if (isNetworkError(error) || isNetworkError(error?.cause)) return 'DISCORD_NETWORK';
    return 'DISCORD_UNKNOWN';
}

/**
 * Classe, code et message expurgé d'une erreur quelconque, pour audit.error().
 * Une erreur de discord.js garde son code DISCORD_* ; ailleurs, `code` s'il
 * ressemble à un code (ECONNRESET, ERR_…, P2002…), ou HTTP_<statut>.
 */
function describeError(error, secrets = []) {
    const isObject = error !== null && typeof error === 'object';
    const identifier = /^[A-Za-z_$][\w$.]{0,63}$/;
    const errorClass = isObject && identifier.test(String(error.name || '')) ? error.name
        : isObject && identifier.test(String(error.constructor?.name || '')) ? error.constructor.name
            : typeof error;
    const constructor = String(error?.constructor?.name || '');
    let errorCode;
    if (['DiscordAPIError', 'HTTPError', 'RateLimitError'].includes(constructor) || typeof error?.auditCode === 'string') {
        errorCode = discordErrorCode(error);
    } else if (typeof error?.code === 'string' && /^[\w.:-]{1,48}$/.test(error.code)) {
        errorCode = error.code;
    } else if (Number.isSafeInteger(error?.code)) {
        errorCode = String(error.code);
    } else {
        const status = error?.status ?? error?.response?.status;
        if (Number.isInteger(status) && status >= 100 && status <= 599) errorCode = 'HTTP_' + status;
    }
    const message = redact(isObject ? error.message ?? '' : error, secrets).trim().slice(0, 300);
    return { errorClass, ...(errorCode ? { errorCode } : {}), ...(message ? { errorMessage: message } : {}) };
}

function normalizeEvent(input, source, secrets = []) {
    if (!categories.includes(input.category)) throw new Error('Unknown audit category');
    if (!/^[a-z][a-z0-9._-]{1,79}$/.test(input.eventType || '')) throw new Error('Invalid audit event type');
    const clean = sanitize(input, secrets);
    const event = {
        eventId: randomUUID(), schemaVersion: 1, source,
        occurredAt: new Date().toISOString(), eventType: input.eventType, category: input.category,
        status: statuses.includes(input.status) ? input.status : 'unknown',
        origin: ['human', 'bot', 'automatic', 'system'].includes(input.origin) ? input.origin : 'unknown'
    };
    // Discret : enregistré en base, jamais affiché sur Discord (commandes de consultation,
    // réception d'une commande dont seul le résultat mérite un embed).
    if (input.quiet === true) event.quiet = true;
    for (const key of ['actorId', 'targetId', 'discordGuildId', 'minecraftGuildId', 'channelId', 'interactionId', 'correlationId']) {
        if (typeof clean[key] === 'string') event[key] = clean[key].slice(0, 100);
    }
    for (const key of ['command', 'subcommand']) {
        if (typeof clean[key] === 'string' && /^[\p{L}\p{N}_-]{1,64}$/u.test(clean[key])) event[key] = clean[key];
    }
    // Rôle concerné (log_event.role_id) ; pseudos et nature bot/humain : l'API en
    // tient log_user à jour, ils n'entrent pas dans log_event (T5, T13).
    if (typeof clean.roleId === 'string' && SNOWFLAKE.test(clean.roleId)) event.roleId = clean.roleId;
    for (const key of ['actorUsername', 'targetUsername']) {
        if (typeof clean[key] === 'string' && clean[key].trim()) event[key] = clean[key].trim().slice(0, 100);
    }
    for (const key of ['actorIsBot', 'targetIsBot']) {
        if (typeof input[key] === 'boolean') event[key] = input[key];
    }
    event.display = {
        title: String(clean.title || input.eventType).slice(0, 180),
        description: typeof clean.description === 'string' ? clean.description : '',
        fields: Array.isArray(clean.fields) ? clean.fields.filter(field => field && typeof field.name === 'string' && field.value != null)
            .slice(0, 20).map(field => ({ name: field.name.slice(0, 80), value: String(field.value).slice(0, 1024) })) : []
    };
    // Preuve de sanction : image affichée dans Discord, jamais stockée en base.
    if (typeof clean.imageUrl === 'string' && /^https:\/\/\S{1,1000}$/.test(clean.imageUrl)) {
        event.display.imageUrl = clean.imageUrl;
    }
    // Aucune métadonnée libre ni texte de message dans la projection BDD : la liste
    // blanche typée lit l'objet d'origine (une Date reste une date) et expurge chaque chaîne.
    event.context = pickContext(input.context, secrets);
    return event;
}

function databaseEvent(event) {
    if (discordOnly.has(event.category)) return null;
    const { display, ...stored } = event;
    return stored;
}

function destinations(event) {
    if (event.origin === 'automatic' || event.eventType === 'guild.chat' || event.eventType === 'guild.online') return [];
    if (event.quiet || event.eventType === 'giveaway.participated' || databaseOnly.has(event.category)) {
        return databaseEvent(event) ? ['database'] : [];
    }
    return databaseEvent(event) ? ['discord', 'database'] : ['discord'];
}

function formatMessage(event) {
    const colors = { success: 0x2ECC71, failed: 0xE74C3C, denied: 0xE67E22, invalid: 0xE67E22, timeout: 0xF1C40F, sent: 0x3498DB };
    const embed = {
        title: event.display.title, description: event.display.description || undefined,
        color: colors[event.status] || 0x95A5A6, timestamp: event.occurredAt,
        footer: { text: event.source + ' • ' + event.eventType + ' • ' + event.eventId }, fields: []
    };
    if (event.display.imageUrl) embed.image = { url: event.display.imageUrl };
    // Mention cliquable sans notification (allowedMentions vide) pour un identifiant Discord.
    const who = id => /^\d{17,20}$/.test(id) ? '<@' + id + '> (' + id + ')' : id;
    const fields = [
        // Le résultat n'informe que pour une commande ou un échec : « success » sur une
        // arrivée de membre ne dit rien.
        ...(event.command || !['success', 'unknown'].includes(event.status) ? [{ name: 'Résultat', value: event.status }] : []),
        ...(event.actorId ? [{ name: 'Acteur', value: who(event.actorId) }] : []),
        ...(event.targetId ? [{ name: 'Cible', value: who(event.targetId) }] : []),
        ...(event.roleId ? [{ name: 'Rôle', value: '<@&' + event.roleId + '> (' + event.roleId + ')' }] : []),
        ...(event.correlationId ? [{ name: 'Corrélation', value: event.correlationId }] : []),
        ...event.display.fields
    ];
    let available = 5900 - embed.title.length - (embed.description?.length || 0) - embed.footer.text.length;
    for (const field of fields.slice(0, 25)) {
        const name = String(field.name || 'Détail').slice(0, 80);
        const value = String(field.value || '—').slice(0, Math.min(1024, available - name.length));
        if (available <= name.length || !value) break;
        embed.fields.push({ name, value, inline: false });
        available -= name.length + value.length;
    }
    return { embeds: [embed], allowedMentions: { parse: [], repliedUser: false } };
}

module.exports = {
    categories, statuses, discordOnly, databaseOnly, CONTEXT_SCHEMA, redact, sanitize, pickContext,
    validateContextValue, discordErrorCode, describeError, normalizeEvent, databaseEvent, destinations, formatMessage
};
