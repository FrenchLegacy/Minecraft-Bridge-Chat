'use strict';

const path = require('path');
const { randomUUID } = require('crypto');
const Outbox = require('./Outbox');
const resolveForumPost = require('./forum');
const {
    normalizeEvent, databaseEvent, destinations, formatMessage, redact, statuses, discordErrorCode, describeError
} = require('./events');

const ERROR_GROUP_MS = 60000;

// Résultat déclaré par le code métier pendant l'exécution d'une commande (voir
// setOutcome). Les handlers renvoient un Message discord.js, pas un statut.
const outcomes = new WeakMap();

/**
 * Déclare le résultat d'une interaction suivie par trackCommand : 'denied' dans
 * le refus de permission, 'invalid' pour une saisie rejetée, 'success' en fin
 * de traitement… Sans déclaration ni exception, le résultat reste 'unknown'.
 */
function setOutcome(interaction, status) {
    if (interaction && typeof interaction === 'object' && statuses.includes(status)) outcomes.set(interaction, status);
}

class AuditLogger {
    /**
     * @param {object} options
     * @param {'discord'|'bridge'|'event'} options.source
     * @param {object} [options.config] bloc audit : enabled, posts, environment, maxBytes,
     *        maxDiscordAttempts (25 par défaut : au-delà, l'envoi Discord est abandonné)
     * @param {string} [options.version] version du bot, envoyée par le heartbeat
     * @param {Function} [options.heartbeatSender] POST /audit/heartbeat (createHttpSenders)
     */
    constructor({ source, config = {}, getClient, dataDir, logger = console, secrets = [], databaseSender, databaseDeliverySender, heartbeatSender, version }) {
        if (!['discord', 'bridge', 'event'].includes(source)) throw new Error('Invalid audit source');
        this.source = source;
        this.instanceId = randomUUID();
        this.config = config;
        this.getClient = getClient;
        this.logger = logger;
        this.secrets = secrets;
        this.databaseSender = databaseSender;
        this.databaseDeliverySender = databaseDeliverySender;
        this.heartbeatSender = heartbeatSender;
        this.version = typeof version === 'string' && version.trim() ? version.trim().slice(0, 32) : null;
        this.maxDiscordAttempts = Number.isSafeInteger(config.maxDiscordAttempts) && config.maxDiscordAttempts > 0
            ? config.maxDiscordAttempts : 25;
        // Démarrage du processus, pas de ce journal : c'est ce que le panneau affiche.
        this.startedAt = new Date(Date.now() - process.uptime() * 1000).toISOString();
        this.heartbeat = null;
        this.botStarted = false;
        this.errorGroups = new Map();
        this.outbox = null;
        this.running = null;
        this.lastDiagnostic = new Map();
        this.receipts = new Map();
        this.receiptWaiters = new Map();
        this.unpostedCategories = new Set();
        if (config.enabled !== true) return;
        this.outbox = new Outbox(path.join(dataDir, 'audit'), config.maxBytes);
        this.start();
    }

    start() {
        if (!this.outbox || this.timer) return;
        this.timer = setInterval(() => this.flush().catch(error => this.diagnostic(error)), 5000);
        this.timer.unref();
        this.flush().catch(error => this.diagnostic(error));
    }

    /**
     * Une catégorie sans post configuré part en base seulement. La garder en file
     * pour Discord la ferait attendre indéfiniment et saturerait la file locale
     * (10 000 événements), qui refuserait alors TOUS les logs. Un post configuré
     * mais inaccessible, lui, reste réessayé : c'est un incident, pas un choix.
     */
    hasPost(category) {
        // Seul un identifiant Discord compte : « ID_POST_… » laissé d'un exemple n'est pas un post.
        if (/^(?:<#)?\d{17,20}>?$/.test(String(this.config.posts?.[category] ?? '').trim())) return true;
        if (!this.unpostedCategories.has(category)) {
            this.unpostedCategories.add(category);
            // Choix de configuration, pas une panne : un avertissement, une fois par catégorie.
            (this.logger.warn || this.logger.error).call(this.logger, '[Audit] Aucun post pour la catégorie ' + category + ' : base de données seulement');
        }
        return false;
    }

    /** Diagnostic local, un par minute et par nature (un abandon ne se perd pas derrière une panne). */
    diagnostic(error, kind = 'delivery') {
        if (Date.now() - (this.lastDiagnostic.get(kind) || 0) < 60000) return;
        this.lastDiagnostic.set(kind, Date.now());
        this.logger.error('[Audit] ' + redact(error.message, this.secrets).slice(0, 250));
    }

    async publish(input) {
        if (!this.outbox) return { accepted: false, reason: 'disabled' };
        try {
            const event = normalizeEvent(input, this.source, this.secrets);
            event.instanceId = this.instanceId;
            event.environment = ['production', 'staging', 'test', 'development'].includes(this.config.environment)
                ? this.config.environment : 'unknown';
            const pending = destinations(event).filter(destination => destination !== 'discord' || this.hasPost(event.category));
            if (!pending.length) return { accepted: false, reason: 'filtered' };
            if (this.databaseDeliverySender && pending.includes('database') && pending.includes('discord')) pending.push('delivery');
            const record = { event, pending, deliveries: {}, attempts: {}, retryAt: {} };
            this.outbox.save(record);
            if (this.outbox.bytes >= this.outbox.maxBytes * 0.8) this.diagnostic(new Error('Audit outbox above 80% capacity'));
            this.flush().catch(error => this.diagnostic(error));
            return { accepted: true, eventId: event.eventId };
        } catch (error) {
            this.diagnostic(error);
            return { accepted: false, reason: 'persistence_failed' };
        }
    }

    async publishAndWait(input) {
        const result = await this.publish(input);
        if (!result.accepted) return null;
        const confirmed = this.receipts.get(result.eventId);
        if (confirmed) return { ...result, id: confirmed.messageId, channelId: confirmed.postId };
        // Moderation callers need the Discord link, not a potentially slow database retry.
        const receipt = await new Promise(resolve => {
            const timer = setTimeout(() => {
                this.receiptWaiters.delete(result.eventId);
                resolve(null);
            }, 2000);
            this.receiptWaiters.set(result.eventId, value => {
                clearTimeout(timer);
                resolve(value);
            });
            this.flush().then(() => this.flush()).catch(error => this.diagnostic(error));
        });
        return { ...result, id: receipt?.messageId || null, channelId: receipt?.postId || null };
    }

    flush(options = {}) {
        if (!this.outbox) return Promise.resolve();
        if (this.running) {
            return options.force ? this.running.then(() => this.flush(options)) : this.running;
        }
        this.running = this.deliver(options).finally(() => { this.running = null; });
        return this.running;
    }

    async deliver({ force = false } = {}) {
        for (const record of this.outbox.records.values()) {
            if (!record.pending.length) this.outbox.remove(record.event.eventId);
        }
        const ready = [...this.outbox.records.values()].filter(record =>
            record.pending.some(destination => (destination !== 'delivery' || record.deliveries.database)
                && (force || !(record.retryAt[destination] > Date.now()))));
        for (const original of ready.slice(0, 100)) {
            let record = original;
            for (const destination of [...record.pending]) {
                // Une destination retirée en cours de boucle (refus définitif) n'est plus servie.
                if (!record.pending.includes(destination)) continue;
                if (destination === 'delivery' && !record.deliveries.database) continue;
                if (!force && record.retryAt[destination] > Date.now()) continue;
                try {
                    let receipt;
                    if (destination === 'discord') {
                        const post = await resolveForumPost(this.getClient(), this.config.posts?.[record.event.category]);
                        const message = await post.send(formatMessage(record.event));
                        receipt = { messageId: message.id, postId: post.id, deliveredAt: new Date().toISOString() };
                    } else if (destination === 'database' || destination === 'delivery') {
                        let response;
                        if (destination === 'database') {
                            if (!this.databaseSender) throw new Error('Audit database delivery not configured');
                            response = await this.databaseSender(databaseEvent(record.event));
                        } else {
                            response = await this.databaseDeliverySender(databaseEvent(record.event), this.deliveryState(record));
                        }
                        if (response?.accepted !== true && response?.permanent === true) {
                            // Refus définitif de l'API (événement invalide) : le rejouer ne
                            // changerait rien et bloquerait la file. Discord n'est pas concerné.
                            record = this.dropDatabase(record, destination, response.reason);
                            continue;
                        }
                        if (response?.accepted !== true) throw new Error('Audit ' + destination + ' not acknowledged');
                        receipt = { accepted: true };
                    } else {
                        throw new Error('Invalid audit destination');
                    }
                    const next = {
                        ...record,
                        pending: record.pending.filter(value => value !== destination),
                        deliveries: { ...record.deliveries, [destination]: receipt }
                    };
                    // Once Discord acknowledged delivery, its body no longer needs to wait for the database.
                    if (destination === 'discord') {
                        next.event = { ...record.event, display: { title: '', description: '', fields: [] } };
                        this.queueDelivery(next);
                    }
                    this.outbox.save(next);
                    if (destination === 'discord') {
                        this.receipts.set(record.event.eventId, receipt);
                        this.receiptWaiters.get(record.event.eventId)?.(receipt);
                        this.receiptWaiters.delete(record.event.eventId);
                        if (this.receipts.size > 256) this.receipts.delete(this.receipts.keys().next().value);
                    }
                    record = next;
                } catch (error) {
                    const attempt = (record.attempts[destination] || 0) + 1;
                    const next = {
                        ...record, attempts: { ...record.attempts, [destination]: attempt },
                        retryAt: { ...record.retryAt, [destination]: Date.now() + Math.min(300000, 5000 * 2 ** Math.min(attempt, 6)) }
                    };
                    if (destination === 'discord') {
                        // Cause réelle, transmise à la BDD par l'accusé de livraison (§1.4).
                        next.errors = { ...record.errors, discord: discordErrorCode(error) };
                        if (attempt >= this.maxDiscordAttempts) {
                            record = this.abandonDiscord(next);
                            this.diagnostic(error);
                            continue;
                        }
                        this.queueDelivery(next);
                    }
                    this.outbox.save(next);
                    record = next;
                    this.diagnostic(error);
                }
            }
            if (!record.pending.length) this.outbox.remove(record.event.eventId);
        }
    }

    /**
     * Abandon Discord après maxDiscordAttempts essais : l'embed n'est plus retenté,
     * son contenu d'affichage est retiré, la copie en base reste et l'accusé
     * envoyé passe à 'failed' (avec le dernier errorCode).
     */
    abandonDiscord(record) {
        const next = {
            ...record,
            event: { ...record.event, display: { title: '', description: '', fields: [] } },
            pending: record.pending.filter(value => value !== 'discord'),
            deliveries: {
                ...record.deliveries,
                discord: { failed: true, errorCode: record.errors?.discord || 'DISCORD_UNKNOWN', failedAt: new Date().toISOString() }
            }
        };
        this.queueDelivery(next);
        this.outbox.save(next);
        this.receiptWaiters.get(record.event.eventId)?.(null);
        this.receiptWaiters.delete(record.event.eventId);
        this.diagnostic(new Error('Audit discord abandoned ' + record.event.eventId + ' after '
            + record.attempts.discord + ' attempts: ' + next.deliveries.discord.errorCode), 'abandon');
        return next;
    }

    dropDatabase(record, destination, reason) {
        const dropped = destination === 'database' ? ['database', 'delivery'] : ['delivery'];
        const next = {
            ...record,
            pending: record.pending.filter(value => !dropped.includes(value)),
            deliveries: { ...record.deliveries, [destination]: { rejected: true } }
        };
        this.outbox.save(next);
        this.diagnostic(new Error('Audit ' + destination + ' rejected ' + record.event.eventId + ': ' + String(reason || 'invalid')));
        return next;
    }

    queueDelivery(record) {
        if (!this.databaseDeliverySender || !databaseEvent(record.event) || record.deliveries.database?.rejected) return;
        record.pending = [...record.pending];
        if (!record.pending.includes('delivery')) record.pending.push('delivery');
        record.retryAt = { ...record.retryAt, delivery: 0 };
    }

    /**
     * Corps de PATCH /audit/events/:eventId/delivery. state : pending, retrying,
     * delivered ou failed (abandon) ; errorCode : DISCORD_<code API>, DISCORD_<HTTP>,
     * DISCORD_NETWORK ou DISCORD_UNKNOWN.
     */
    deliveryState(record) {
        const receipt = record.deliveries.discord;
        const failed = receipt?.failed === true;
        const delivered = Boolean(receipt) && !failed;
        const configured = String(this.config.posts?.[record.event.category] || '');
        const postId = (delivered && receipt.postId) || configured.match(/^(?:<#)?(\d{17,20})>?$/)?.[1] || null;
        return {
            state: delivered ? 'delivered' : failed ? 'failed' : record.attempts.discord ? 'retrying' : 'pending',
            attempts: (record.attempts.discord || 0) + (delivered ? 1 : 0),
            nextRetryAt: !receipt && record.retryAt.discord ? new Date(record.retryAt.discord).toISOString() : null,
            errorCode: delivered ? null : failed ? receipt.errorCode
                : record.attempts.discord ? record.errors?.discord || 'DISCORD_UNKNOWN' : null,
            deliveredAt: delivered ? receipt.deliveredAt || null : null,
            messageId: delivered ? receipt.messageId || null : null, postId
        };
    }

    /**
     * @param {object} [options]
     * @param {boolean} [options.quiet] commande de consultation : résultat en base seulement
     * @param {string} [options.defaultStatus] résultat sans déclaration ni exception
     *        (ex. 'success' pour une consultation) ; 'unknown' par défaut
     */
    async trackCommand(interaction, execute, { quiet = false, defaultStatus = 'unknown' } = {}) {
        let subcommand;
        try { subcommand = interaction.options?.getSubcommand(false); } catch {}
        return this.track(interaction, execute, {
            prefix: 'command', quiet, defaultStatus,
            base: { command: interaction.commandName, subcommand, title: '/' + interaction.commandName + (subcommand ? ' ' + subcommand : '') }
        });
    }

    /**
     * Bouton, menu ou formulaire : même suivi qu'une commande, sous le nom stable
     * de l'action (`ticket_close`, pas son customId qui porte des identifiants).
     * Discret par défaut : le détail va en base, le forum ne montre que les échecs
     * — les événements métier (ticket.open, candidature.refused…) racontent le reste.
     *
     * @param {object} options
     * @param {string} options.name   nom stable de l'action ([\p{L}\p{N}_-]{1,64})
     * @param {string} [options.kind] 'button' | 'select' | 'modal'
     * @param {boolean} [options.quiet=true]
     */
    async trackInteraction(interaction, execute, { name, kind = 'component', quiet = true } = {}) {
        return this.track(interaction, execute, {
            prefix: 'interaction', quiet,
            base: { command: name, subcommand: kind, title: '🔘 ' + name }
        });
    }

    /** @private Réception + résultat, même corrélation ; la valeur et les exceptions sont préservées. */
    async track(interaction, execute, { prefix, quiet, defaultStatus = 'unknown', base: specific }) {
        const correlationId = interaction.id || randomUUID();
        const base = {
            category: 'commandes', correlationId, ...specific,
            interactionId: interaction.id, actorId: interaction.user?.id, discordGuildId: interaction.guildId,
            channelId: interaction.channelId, origin: interaction.commandOrigin || (interaction.user?.bot ? 'bot' : 'human')
        };
        const started = Date.now();
        // La réception ne sert qu'à dater et corréler : en base, jamais en embed.
        await this.publish({ ...base, eventType: prefix + '.received', status: 'unknown', quiet: true });
        try {
            const result = await execute();
            const status = statuses.includes(result?.status) ? result.status
                : outcomes.get(interaction) || (statuses.includes(defaultStatus) ? defaultStatus : 'unknown');
            await this.publish({ ...base, eventType: prefix + '.result', status, quiet, context: { durationMs: Date.now() - started } });
            return result;
        } catch (error) {
            // Un échec s'affiche toujours, même pour une action discrète.
            await this.publish({ ...base, eventType: prefix + '.result', status: 'failed', context: { durationMs: Date.now() - started } });
            throw error;
        } finally {
            outcomes.delete(interaction);
        }
    }

    /**
     * Santé du bot (T9) : POST /audit/heartbeat tout de suite, puis à chaque
     * intervalle. Hors file locale : un battement perdu est remplacé par le
     * suivant ; un échec ne laisse qu'un diagnostic. Le premier appel émet
     * aussi `bot.started` : l'appeler quand le bot est prêt (événement ready).
     *
     * @param {object} [options]
     * @param {number} [options.intervalMs=60000] entre 10 s et 1 h
     * @param {Function} [options.metrics] () => objet (ou promesse) de nombres :
     *        wsPingMs remplace le ping lu sur le client Discord ; les autres clés
     *        (10 au plus) vont dans `extra` (ex. { connectedAccounts: 2 })
     * @param {string} [options.version] remplace la version passée au constructeur
     * @returns {Promise<boolean>} premier envoi réussi ou non ; jamais rejetée
     */
    startHeartbeat({ intervalMs = 60000, metrics, version } = {}) {
        if (!this.outbox) return Promise.resolve(false);
        this.stopHeartbeat();
        if (typeof version === 'string' && version.trim()) this.version = version.trim().slice(0, 32);
        if (!this.botStarted) {
            this.botStarted = true;
            this.publish({
                eventType: 'bot.started', category: 'statut-bots', status: 'success', origin: 'system', quiet: true,
                title: 'Démarrage ' + this.source + (this.version ? ' ' + this.version : '')
            }).catch(error => this.diagnostic(error));
        }
        if (typeof this.heartbeatSender !== 'function') {
            (this.logger.warn || this.logger.error).call(this.logger, '[Audit] heartbeatSender absent : aucun battement envoyé');
            return Promise.resolve(false);
        }
        const period = Math.min(3600000, Math.max(10000, Number.isFinite(intervalMs) ? intervalMs : 60000));
        const heartbeat = { metrics: typeof metrics === 'function' ? metrics : null, inFlight: null, failing: false };
        heartbeat.timer = setInterval(() => { this.beat(heartbeat); }, period);
        heartbeat.timer.unref();
        this.heartbeat = heartbeat;
        return this.beat(heartbeat);
    }

    stopHeartbeat() {
        if (this.heartbeat) clearInterval(this.heartbeat.timer);
        this.heartbeat = null;
    }

    /** @private Un seul battement à la fois ; jamais d'exception. */
    beat(heartbeat) {
        if (heartbeat.inFlight) return heartbeat.inFlight;
        const run = async () => {
            try {
                const response = await this.heartbeatSender(await this.heartbeatPayload(heartbeat));
                if (response?.accepted !== true) throw new Error('Audit heartbeat not acknowledged');
                if (heartbeat.failing) this.logger.error('[Audit] Heartbeat rétabli');
                heartbeat.failing = false;
                return true;
            } catch (error) {
                this.heartbeatFailure(heartbeat, error);
                return false;
            }
        };
        heartbeat.inFlight = run().finally(() => { heartbeat.inFlight = null; });
        return heartbeat.inFlight;
    }

    /**
     * @private Une ligne au premier échec d'une série, pas une par minute : le
     * créneau de diagnostic() reste libre pour les pannes de livraison.
     */
    heartbeatFailure(heartbeat, error) {
        if (heartbeat.failing) return;
        heartbeat.failing = true;
        this.logger.error('[Audit] Heartbeat : ' + redact(error?.message, this.secrets).slice(0, 250));
    }

    /** Corps de POST /audit/heartbeat (PLAN_DONNEES §1.5). */
    async heartbeatPayload(heartbeat = {}) {
        let measured = {};
        if (heartbeat.metrics) {
            try {
                const value = await heartbeat.metrics();
                if (value && typeof value === 'object') measured = value;
            } catch (error) {
                // Mesures du bot indisponibles : le battement part quand même (signalé une fois).
                if (!heartbeat.metricsWarned) this.logger.error('[Audit] Heartbeat, metrics() : ' + redact(error?.message, this.secrets).slice(0, 250));
                heartbeat.metricsWarned = true;
            }
        }
        const number = value => (typeof value === 'number' && Number.isFinite(value) && value >= 0 ? Math.round(value) : null);
        let wsPingMs = number(measured.wsPingMs);
        if (wsPingMs === null) {
            // discord.js vaut -1 (ou null) avant le premier battement de la passerelle.
            try { wsPingMs = number(this.getClient?.()?.ws?.ping); } catch { wsPingMs = null; }
        }
        const extra = {};
        for (const [key, value] of Object.entries(measured)) {
            if (key === 'wsPingMs' || !/^[A-Za-z][A-Za-z0-9_]{0,39}$/.test(key)) continue;
            if (typeof value !== 'number' || !Number.isFinite(value)) continue;
            extra[key] = value;
            if (Object.keys(extra).length >= 10) break;
        }
        return {
            source: this.source, instanceId: this.instanceId, version: this.version, startedAt: this.startedAt,
            uptimeSec: Math.floor(process.uptime()), wsPingMs,
            memoryRssMb: Math.round(process.memoryUsage.rss() / 1048576),
            outboxPending: this.outbox?.records.size ?? 0, extra
        };
    }

    /**
     * Erreur applicative (T10) → `app.error`, catégorie technique, origine system,
     * avec errorClass, errorCode et errorMessage expurgé. Même classe et même
     * message : un envoi par minute au plus ; `context.count` compte les occurrences
     * depuis le précédent envoi, et un reliquat part à la fin de la minute.
     * Ne lève jamais : utilisable dans n'importe quel catch.
     *
     * @param {*} error
     * @param {object} [options]
     * @param {string} [options.where] emplacement lisible (« ticket.close », « guildMemberAdd »…),
     *        affiché sur Discord seulement
     * @param {object} [options.context] clés de CONTEXT_SCHEMA (errorCode y remplace le code déduit)
     * @returns {Promise<object>} résultat de publish(), ou { accepted: false, reason: 'grouped' }
     */
    error(error, { where, context } = {}) {
        try {
            const details = describeError(error, this.secrets);
            const occurrence = { details, where: typeof where === 'string' ? where.slice(0, 100) : '', context };
            const key = details.errorClass + '\n' + (details.errorMessage || '');
            const group = this.errorGroups.get(key);
            if (group && Date.now() - group.sentAt < ERROR_GROUP_MS) {
                group.count++;
                group.last = occurrence;
                if (!group.timer) {
                    group.timer = setTimeout(() => this.sendErrorGroup(key), group.sentAt + ERROR_GROUP_MS - Date.now());
                    group.timer.unref();
                }
                return Promise.resolve({ accepted: false, reason: 'grouped' });
            }
            return this.sendError(key, occurrence, (group?.count || 0) + 1);
        } catch (failure) {
            this.diagnostic(failure);
            return Promise.resolve({ accepted: false, reason: 'persistence_failed' });
        }
    }

    /** @private Reliquat d'un groupe à la fin de sa minute (ou à la fermeture). */
    sendErrorGroup(key) {
        const group = this.errorGroups.get(key);
        if (!group?.count) return Promise.resolve(null);
        return this.sendError(key, group.last, group.count).catch(error => this.diagnostic(error));
    }

    /** @private */
    sendError(key, { details, where, context }, count) {
        clearTimeout(this.errorGroups.get(key)?.timer);
        this.errorGroups.delete(key);
        this.errorGroups.set(key, { sentAt: Date.now(), count: 0, timer: null, last: null });
        // Groupes révolus oubliés : la table ne grossit pas avec des erreurs uniques.
        for (const [other, group] of this.errorGroups) {
            if (this.errorGroups.size <= 200) break;
            if (Date.now() - group.sentAt < ERROR_GROUP_MS) continue;
            clearTimeout(group.timer);
            this.errorGroups.delete(other);
        }
        const fields = [
            ...(where ? [{ name: 'Emplacement', value: where }] : []),
            { name: 'Erreur', value: details.errorClass + (details.errorMessage ? ' : ' + details.errorMessage : '') },
            ...(details.errorCode ? [{ name: 'Code', value: details.errorCode }] : []),
            ...(count > 1 ? [{ name: 'Occurrences', value: String(count) + ' depuis le dernier signalement' }] : [])
        ];
        return this.publish({
            eventType: 'app.error', category: 'technique', status: 'failed', origin: 'system',
            title: 'Erreur' + (where ? ' — ' + where : ''), fields,
            context: { ...(context && typeof context === 'object' ? context : {}), ...details, ...(context?.errorCode ? { errorCode: context.errorCode } : {}), count }
        });
    }

    /**
     * Arrêt : reliquats d'erreurs regroupées puis `bot.stopped` (si `bot.started`
     * a été émis) enregistrés, et une dernière livraison tentée pendant 3 s au
     * plus. Ce qui n'est pas livré reste dans la file et part au redémarrage.
     */
    close() {
        this.stopHeartbeat();
        let pending = false;
        for (const [key, group] of [...this.errorGroups]) {
            clearTimeout(group.timer);
            if (group.count) {
                this.sendErrorGroup(key);
                pending = true;
            }
        }
        this.errorGroups.clear();
        if (this.botStarted && this.outbox) {
            this.botStarted = false;
            this.publish({
                eventType: 'bot.stopped', category: 'statut-bots', status: 'success', origin: 'system', quiet: true,
                title: 'Arrêt ' + this.source
            }).catch(error => this.diagnostic(error));
            pending = true;
        }
        clearInterval(this.timer);
        this.timer = null;
        for (const resolve of this.receiptWaiters.values()) resolve(null);
        this.receiptWaiters.clear();
        if (!pending) return this.running || Promise.resolve();
        let timeout;
        return Promise.race([
            this.flush({ force: true }).catch(error => this.diagnostic(error)),
            new Promise(resolve => { timeout = setTimeout(resolve, 3000); timeout.unref(); })
        ]).finally(() => clearTimeout(timeout));
    }
}

module.exports = AuditLogger;
module.exports.setOutcome = setOutcome;
