'use strict';

// Un contrôle local qui anticipe une réponse de Discord en porte le code
// (errorCode de la livraison, PLAN_DONNEES §1.4) ; les autres restent DISCORD_UNKNOWN.
function refuse(message, auditCode) {
    const error = new Error(message);
    if (auditCode) error.auditCode = auditCode;
    return error;
}

async function resolveForumPost(client, postId) {
    const id = String(postId || '').replace(/^<#(\d+)>$/, '$1').trim();
    if (!/^\d{17,20}$/.test(id)) throw new Error('Audit forum post ID missing or invalid');
    // Passerelle déconnectée : même nature qu'une panne réseau.
    if (!client?.isReady()) throw refuse('Discord not ready for audit delivery', 'DISCORD_NETWORK');
    const thread = await client.channels.fetch(id);
    if (!thread?.isThread?.()) throw new Error('Audit destination is not a thread');
    const parent = thread.parent || await client.channels.fetch(thread.parentId);
    if (parent?.type !== 15) throw new Error('Audit thread is not a forum post');
    if (thread.locked) throw new Error('Audit forum post is locked');
    const permissions = thread.permissionsFor(client.user);
    for (const permission of ['ViewChannel', 'SendMessagesInThreads', 'EmbedLinks', 'ReadMessageHistory']) {
        // 50013 = Missing Permissions : ce que Discord répondrait à l'envoi.
        if (!permissions?.has(permission)) throw refuse('Missing audit permission: ' + permission, 'DISCORD_50013');
    }
    if (thread.archived) {
        if (!permissions.has('ManageThreads')) throw refuse('Missing audit permission: ManageThreads', 'DISCORD_50013');
        await thread.setArchived(false);
    }
    return thread;
}

module.exports = resolveForumPost;
