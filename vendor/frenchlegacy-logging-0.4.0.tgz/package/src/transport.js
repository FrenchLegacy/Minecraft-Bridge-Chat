'use strict';

/**
 * Transport HTTP vers les routes /audit de FrenchLegacy-API.
 *
 * Fetch natif (Node 22+), aucune dépendance : les trois bots l'utilisent de la
 * même façon, y compris le bridge qui n'embarque pas @frenchlegacy/api-client.
 *
 *   const senders = createHttpSenders({ baseUrl, apiKey });
 *   new AuditLogger({ ..., ...senders });   // databaseSender, databaseDeliverySender, heartbeatSender
 *
 * Contrat avec AuditLogger :
 *   { accepted: true }                  l'API a stocké (ou avait déjà stocké) l'événement ;
 *   { accepted: false, permanent: true } l'API le refuse pour de bon (404/422) : abandon ;
 *   exception                           tout le reste — réseau, 5xx, 503, 401/403 de
 *                                       configuration : l'événement reste en file.
 *
 * heartbeatSender(payload) : POST /audit/heartbeat, même authentification. Tout
 * 2xx vaut { accepted: true } ; le reste lève. Jamais mis en file (AuditLogger).
 */

function createHttpSenders({ baseUrl, apiKey, timeoutMs = 10000, fetchImpl = globalThis.fetch } = {}) {
    const base = String(baseUrl || '').replace(/\/+$/, '');
    if (!/^https?:\/\/[^\s/]+/.test(base)) throw new Error('Audit transport: invalid baseUrl');
    if (typeof apiKey !== 'string' || apiKey.length < 8) throw new Error('Audit transport: missing apiKey');
    if (typeof fetchImpl !== 'function') throw new Error('Audit transport: fetch unavailable (Node 22+ required)');

    async function call(method, path, body, { anySuccess = false } = {}) {
        const response = await fetchImpl(base + path, {
            method,
            headers: { 'content-type': 'application/json', accept: 'application/json', 'x-api-key': apiKey },
            body: JSON.stringify(body),
            signal: AbortSignal.timeout(timeoutMs)
        });
        let data = null;
        try { data = await response.json(); } catch { /* corps vide ou non JSON */ }
        if (response.ok && (anySuccess || data?.accepted === true)) return { accepted: true };
        if ((response.status === 404 || response.status === 422) && data?.permanent === true) {
            return { accepted: false, permanent: true, reason: String(data.error || response.status).slice(0, 200) };
        }
        // Jamais la clé ni le corps dans le message : il finit dans les diagnostics.
        throw new Error('Audit API ' + method + ' ' + path.split('/').slice(0, 3).join('/') + ' -> HTTP ' + response.status);
    }

    return {
        databaseSender: event => call('POST', '/audit/events', event),
        databaseDeliverySender: (event, delivery) =>
            call('PATCH', '/audit/events/' + encodeURIComponent(event.eventId) + '/delivery', delivery),
        heartbeatSender: payload => call('POST', '/audit/heartbeat', payload, { anySuccess: true })
    };
}

module.exports = { createHttpSenders };
