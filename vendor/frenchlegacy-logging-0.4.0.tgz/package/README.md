# @frenchlegacy/logging

Paquet CommonJS partagé par les trois bots. Node 22+, aucune dépendance supplémentaire.

## Contrat

- Événement validé, identifiant UUID, source, instance, environnement, date, statut et catégorie.
- Secrets connus de la configuration et motifs usuels masqués avant écriture.
- Format Discord uniforme et mentions neutralisées.
- Destination : ID d’un post existant dont le parent est un forum ; pas de création automatique. Une catégorie sans ID Discord valide dans `audit.posts` part en base seulement (un avertissement par catégorie) : elle ne reste jamais en file pour Discord, ce qui saturerait la file et bloquerait tous les logs.
- `quiet: true` : enregistré en base, jamais affiché. `trackCommand` l'applique à la réception de toute commande (un seul embed : le résultat) et, avec `{ quiet: true }`, au résultat d'une commande de consultation — sauf en cas d'échec.
- Post archivé : réouverture après contrôle des droits. Post verrouillé, absent ou inaccessible : livraison conservée.
- Écriture atomique avec synchronisation du fichier avant acceptation. File locale limitée à 25 Mio et 10 000 événements ; enregistrements limités à 64 Kio.
- Reprise au démarrage et toutes les cinq secondes, un seul travailleur, lots de 100 et backoff jusqu’à cinq minutes par destination.
- Accusés séparés Discord/BDD. Le contenu d’affichage est retiré après livraison Discord, même si la BDD est en panne.
- DM (`prives`) : Discord seulement, jamais en BDD. Connexions en jeu et XP (`connexions-jeu`, `xp`) : BDD seulement, jamais sur Discord, même avec un post configuré. Tout le reste, archives de tickets comprises, part en BDD en **métadonnées seules** : jamais de titre, de description, de champ ni de texte de message dans la projection BDD.
- Après `audit.maxDiscordAttempts` essais Discord (25 par défaut, soit environ 1 h 40 avec le backoff), l'embed est abandonné : la copie en BDD reste, l'accusé de livraison passe à `failed`.
- Commandes automatiques, chat de guilde et liste des joueurs en ligne filtrés. Un retour de handler sans statut reste inconnu.

publish() renvoie accepted: true après persistance, pas après livraison. Un refus explicite porte reason: disabled, filtered ou persistence_failed. Une erreur de configuration, validation, quota ou disque ne devient jamais un faux succès.

publishAndWait() tente aussi la livraison et renvoie les IDs Discord quand un accusé est disponible ; sinon ils restent nuls. Cette méthode conserve le contrat des anciens appels qui attachent le message de log à une sanction.

trackCommand(interaction, execute) enregistre réception et résultat avec la même corrélation. Il conserve la valeur de retour et les exceptions métier. Une erreur de persistance est signalée localement ; elle ne relance pas l’action métier.

Le résultat vient, dans l'ordre : du `status` renvoyé par le handler, de setOutcome(interaction, status) appelé pendant l'exécution (refus de permission → `denied`, saisie rejetée → `invalid`…), sinon `unknown`. Une exception donne `failed`.

## Taxonomie

Les 24 catégories de `src/events.js` sont les codes de la table `log_category` du schéma
`frenchlegacy_logs` (voir `migration/logs/DECISIONS.md`, M21) : historique importé et événements en
direct partagent les mêmes codes. Ajouter une catégorie ici impose de l'ajouter aussi à
`CATEGORIES_DIRECT` dans `migration/logs/build_sql.js`, puis de régénérer et appliquer
`00_dimensions.sql` — sinon l'API la refuse (422).

## Nouveautés 0.4.0 (PLAN_DONNEES §1)

### Champs de premier niveau

| Champ | Validation | Devenir |
| --- | --- | --- |
| `roleId` | snowflake, sinon jeté | `log_event.role_id` ; affiché dans l'embed (« Rôle », mention sans notification) |
| `actorUsername`, `targetUsername` | chaîne, tronquée à 100 | l'API tient `log_user.last_username` ; jamais dans `log_event` |
| `actorIsBot`, `targetIsBot` | booléen strict, sinon jeté | `log_user.is_bot` |

```js
audit.publish({ eventType: 'member.role.add', category: 'roles', status: 'success', origin: 'human',
    actorId: executor.id, actorUsername: executor.username, actorIsBot: executor.bot,
    targetId: member.id, targetUsername: member.user.username, targetIsBot: member.user.bot,
    roleId: role.id, context: { roleAction: 'add' } });
```

### `context` : liste blanche typée

`CONTEXT_SCHEMA` (exporté, gelé) décrit chaque clé admise ; `pickContext(context, secrets)` l'applique.
Toute autre clé, et toute valeur du mauvais type, est jetée. Chaque chaîne passe par `redact()`.
L'API doit appliquer la même liste (`FrenchLegacy-API/src/audit/normalize.js`).

| Clé | Type | Règle |
| --- | --- | --- |
| `messageId`, `entityId` | `id` | chaîne non vide ≤ 100 ou entier ≥ 0 (clés historiques) |
| `requestedCount`, `deletedCount`, `level`, `count` | `integer` | entier ≥ 0 ; une chaîne de chiffres est convertie |
| `durationMs`, `sanctionDurationMs` | `integer` (arrondi) | entier ≥ 0 ; un décimal est arrondi |
| `reason` | `text` 300 | tronqué à 300 |
| `targetName`, `oldName`, `newName` | `text` 100 | tronqué à 100 |
| `errorMessage` | `text` 300 | expurgé, tronqué à 300 ; message applicatif, jamais celui d'un utilisateur |
| `ticketType`, `ticketVariant` | `string` 32 | jeté au-delà de 32 |
| `errorCode` | `string` 48 | jeté au-delà de 48 |
| `errorClass` | `string` 64 | jeté au-delà de 64 |
| `relatedEventId` | `string` 64 | jeté au-delà de 64 ; un entier est converti en chaîne |
| `expiresAt` | `date` | ISO 8601 ou `Date`, renvoyé en ISO UTC (`…Z`) |
| `targetEntityId`, `fromChannelId`, `toChannelId` | `snowflake` | 17 à 20 chiffres, en chaîne |
| `transcriptUrl` | `url` 300 | `https://` seulement, jeté au-delà de 300 |
| `minecraftUuid` | `uuid` | 32 ou 36 hexadécimaux, mis en minuscules |
| `targetType` | `enum` | `channel`, `role`, `webhook`, `automod_rule`, `scheduled_event`, `emoji`, `sticker`, `invite`, `integration`, `thread`, `guild`, `user`, `message`, `stage`, `soundboard`, `command` |
| `roleAction` | `enum` | `add`, `remove` |
| `voiceAction` | `enum` | `mute`, `unmute`, `deafen`, `undeafen`, `move`, `disconnect` |
| `stage` | `enum` | `received`, `sent`, `response` |

`text` est un texte libre (tronqué) ; `string` un code ou un identifiant (jeté plutôt que faussé).

### Livraison Discord : cause et abandon

L'accusé `PATCH /audit/events/:eventId/delivery` porte `state` (`pending`, `retrying`, `delivered` ou
`failed`) et `errorCode`, calculé par `discordErrorCode(error)` :

- `DISCORD_<code API>` : `DiscordAPIError.code` (ex. `DISCORD_50013`). `forum.js` pose aussi `DISCORD_50013` quand une permission manque.
- `DISCORD_<statut HTTP>` : statut sans code API (ex. `DISCORD_503`). `RateLimitError` donne `DISCORD_429`.
- `DISCORD_NETWORK` : panne réseau, délai dépassé, passerelle non prête.
- `DISCORD_UNKNOWN` : tout le reste (post mal configuré, verrouillé…).

Au `maxDiscordAttempts`-ième échec, l'événement n'est plus retenté pour Discord. Son contenu d'affichage est
retiré, et l'accusé `failed` part avec le dernier `errorCode`. La copie en BDD est conservée. Un événement
Discord seul (MP) est alors retiré de la file. Un diagnostic local le signale.

### Santé : heartbeat, démarrage, arrêt

```js
const audit = new AuditLogger({ source: 'bridge', config, getClient, dataDir, secrets,
    version: require('../package.json').version,
    ...createHttpSenders({ baseUrl, apiKey })   // databaseSender, databaseDeliverySender, heartbeatSender
});
client.once('ready', () => audit.startHeartbeat({ metrics: () => ({ connectedAccounts: bots.filter(b => b.online).length }) }));
process.once('SIGTERM', async () => { await audit.close(); process.exit(0); });
```

`startHeartbeat({ intervalMs = 60000, metrics, version })` envoie `POST /audit/heartbeat` tout de suite, puis
à chaque intervalle (borné entre 10 s et 1 h, timer `unref()`). L'authentification est celle de
`POST /audit/events`. Corps :

```json
{ "source": "bridge", "instanceId": "<uuid>", "version": "1.4.0", "startedAt": "2026-09-30T08:00:00.000Z",
  "uptimeSec": 3600, "wsPingMs": 48, "memoryRssMb": 142, "outboxPending": 0, "extra": { "connectedAccounts": 2 } }
```

- `startedAt` et `uptimeSec` sont ceux du processus. `outboxPending` compte les enregistrements en file.
- `wsPingMs` vient de `metrics().wsPingMs`, sinon de `client.ws.ping`. Il vaut `null` s'il est inconnu ou négatif.
- `metrics` est une fonction optionnelle, synchrone ou asynchrone. Elle renvoie des nombres. Hors `wsPingMs`, les 10 premières clés numériques (`[A-Za-z][A-Za-z0-9_]{0,39}`) vont dans `extra`, qui est toujours un objet.
- Tout 2xx vaut acquittement.
- Un échec n'est jamais mis en file : le battement suivant le remplace. Une ligne de log apparaît au premier échec d'une série, puis une autre au rétablissement. Une erreur de `metrics()` n'empêche pas l'envoi.
- Sans `heartbeatSender`, ou si l'audit est désactivé, rien n'est envoyé.

Le premier `startHeartbeat()` émet `bot.started`. Un appel suivant, après une reconnexion, n'émet rien. Le
démarrage est ainsi daté quand le bot se déclare prêt, pas à la construction du journal. `close()` émet
`bot.stopped` si `bot.started` l'a été. Les deux sont en catégorie `statut-bots`, `quiet` (BDD seulement),
d'origine `system`.

`close()` arrête le heartbeat et enregistre `bot.stopped` et les reliquats d'erreurs regroupées. Il tente
ensuite une dernière livraison pendant 3 s au plus. Ce qui reste part au redémarrage.

### Erreurs applicatives : `audit.error(err, { where, context })`

```js
process.on('unhandledRejection', error => audit.error(error, { where: 'unhandledRejection' }));
try { … } catch (error) { audit.error(error, { where: 'ticket.close', context: { relatedEventId: ticketId } }); throw error; }
```

- L'événement émis est `app.error` : catégorie `technique`, statut `failed`, origine `system`.
- `context` reçoit `errorClass`, `errorCode` et `errorMessage` (expurgé, 300 caractères au plus), calculés par `describeError()`. Il reçoit aussi `count` et les clés admises du `context` fourni. Un `context.errorCode` fourni l'emporte.
- `errorCode` vaut `DISCORD_*` pour une erreur discord.js. Sinon, c'est `error.code` s'il a la forme d'un code, ou `HTTP_<statut>`.
- `where` n'apparaît que dans l'embed : il n'a pas de clé dans la liste blanche.
- Même classe et même message : un envoi par minute au plus. Les occurrences suivantes sont retenues (`{ accepted: false, reason: 'grouped' }`). Elles partent en un seul événement à la fin de la minute, avec `context.count` = nombre d'occurrences depuis l'envoi précédent. `close()` enregistre les reliquats.
- La méthode ne lève jamais.

## Intégration progressive

Le bloc audit devient autoritaire dès qu’il existe. audit.enabled: false coupe ce chemin sans retomber sur les anciens salons. Sans bloc audit, les adaptateurs des bots conservent le fonctionnement antérieur.

Renseigner audit.posts avec les IDs des posts de forum, puis activer seulement après recette. Les fichiers d’exemple livrés gardent ce mode désactivé ; aucun vrai fichier de settings n’est modifié.

Le callback optionnel databaseSender(event) doit confirmer { accepted: true } seulement après stockage idempotent par event.eventId. createHttpSenders({ baseUrl, apiKey }) fournit databaseSender et databaseDeliverySender sur les routes authentifiées POST /audit/events et PATCH /audit/events/:eventId/delivery de FrenchLegacy-API (fetch natif, aucune dépendance). Une réponse { accepted: false, permanent: true } (HTTP 404/422) retire l'événement de la file BDD sans toucher à sa livraison Discord ; toute autre erreur, 401/403 compris, le garde en file. L’acceptation n’est confirmée qu’après stockage idempotent par l’API. Le callback databaseDeliverySender(event, delivery) confirme séparément les accusés Discord en BDD. Les deux restent dans la même file locale jusqu’à leur acquittement. Préparer les tables et les clés API, puis effectuer la recette avant activation.

Le vieux DiscordLogger transmet encore ses titres et champs via un adaptateur. Les événements métier structurés, références de sanctions, résumés XP, archives et journalisation exhaustive des boutons/formulaires restent à migrer. Les fichiers techniques actuels restent gérés par les loggers existants.

## Limites de livraison

Un crash après envoi Discord mais avant sauvegarde de l’accusé peut produire un doublon à la reprise. La BDD doit dédupliquer avec l’UUID ; aucune garantie « exactement une fois » sur Discord. L’écriture synchronisée protège les événements acceptés contre un arrêt du processus ; une panne matérielle/disque sort de cette garantie.

Un fichier illisible dans la file bloque son chargement et reste sur disque pour inspection. Pas d’effacement silencieux ni d’archive automatique du contenu sensible. Les diagnostics sont locaux, limités à un par minute et par nature (livraison, abandon) ; les erreurs applicatives remontées par `audit.error()` sont regroupées dans le post technique (voir plus bas).

Le rendu respecte les limites d’un embed : les détails trop longs sont bornés. Il ne remplace pas un transcript ou une archive intégrale des pièces jointes. Les DM transmettent texte et liens de pièces jointes, sans télécharger les fichiers.

## Distribution locale

Les bots consomment le même fichier vendor/frenchlegacy-logging-0.4.0.tgz via une dépendance file:. Chaque Dockerfile le copie avant l’installation des paquets ; aucun registre privé supplémentaire ni publication nécessaire.

Source à maintenir : ce dossier. Après modification : lancer les tests, puis `npm run vendor -- ../FrenchLegacy-Discord [../Minecraft-Bridge-Chat ../FrenchLegacy-Event]`. Le script crée l’archive dans `vendor/` du bot, met à jour sa dépendance et inscrit dans son verrou l’empreinte **réelle** de l’archive. À ne pas faire à la main : à version égale, `npm install --package-lock-only` garde l’ancienne empreinte et `npm ci` échoue au build (EINTEGRITY). Ne pas éditer trois copies du code partagé.

Tests : node --test test/*.test.js.

Références : [threads et permissions Discord](https://docs.discord.com/developers/topics/threads), [limites des messages](https://docs.discord.com/developers/resources/message), [dépendances locales npm](https://docs.npmjs.com/cli/v11/configuring-npm/package-json/).